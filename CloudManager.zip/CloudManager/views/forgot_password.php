<!DOCTYPE html>
<html lang="id" class="h-full">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Forgot Password - <?= \App\Core\Config::APP_NAME ?></title>
    
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">

    <style>
        body { font-family: 'Inter', sans-serif; }
        .fade-in { animation: fadeIn 0.6s cubic-bezier(0.22, 1, 0.36, 1); }
        @keyframes fadeIn { from { opacity: 0; transform: translateY(15px); } to { opacity: 1; transform: translateY(0); } }
    </style>
</head>

<body class="h-full flex items-center justify-center bg-cover bg-center overflow-hidden" 
      style="background-image: url('<?= $loginBanner ?>');">
    
    <div class="absolute inset-0 bg-black/20"></div>

    <div class="w-[390px] rounded-lg shadow-2xl overflow-hidden relative z-10 fade-in flex flex-col">
        
        <div class="h-[120px] bg-gray-900/70 backdrop-blur-md relative flex flex-col items-center justify-center border-b border-white/10">
            <div class="flex items-center gap-1 mb-1 transform scale-95 origin-bottom">
                <span class="text-3xl font-bold text-[#4facfe] tracking-tight">Brother</span>
                <span class="text-3xl font-bold text-[#a18cd1] tracking-tight">Line</span>
                <span class="text-xl text-gray-300 font-medium ml-2 mt-2 tracking-tight">Cloud</span>
            </div>
            <div class="absolute bottom-3 right-4 text-white/60 text-[10px] font-light tracking-wide">
                —— Information
            </div>
        </div>

        <div class="bg-white px-10 py-10 text-center">
            
            <div class="mb-4 flex justify-center">
                <div class="w-12 h-12 bg-blue-50 text-blue-500 rounded-full flex items-center justify-center">
                    <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z"></path></svg>
                </div>
            </div>

            <h3 class="text-gray-800 font-semibold text-sm mb-3">Feature Disabled</h3>
            <p class="text-xs text-gray-500 leading-relaxed mb-8">
                We have removed the forgot password feature to protect user confidentiality. You can contact the developer for further information.
            </p>

            <a href="index.php" class="block w-full bg-gray-100 hover:bg-gray-200 text-gray-600 text-xs font-semibold py-2.5 rounded shadow-sm transition-all active:scale-[0.98] tracking-wide uppercase">
                Back to Login
            </a>
        </div>
    </div>

    <?= \App\Helpers\ViewHelper::footer() ?>

</body>
</html>