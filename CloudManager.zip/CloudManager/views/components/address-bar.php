<div class="h-9 flex items-center gap-2 px-3 border-b border-gray-300 bg-white">
    <div class="flex items-center gap-1 text-gray-500">

        <button @click="loadPath(currentPath.substring(0, currentPath.lastIndexOf('/')) || '/')" class="hover:text-blue-600 p-0.5" title="Up one level">
            <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 10l7-7m0 0l7 7m-7-7v18"></path>
            </svg>
        </button>

        <button @click="loadPath(projectPath)" class="hover:text-blue-600 p-0.5 text-blue-500" title="Jump to Project Root">
            <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 5l7 7-7 7M5 5l7 7-7 7"></path>
            </svg>
        </button>

    </div>

    <div class="flex-1 flex items-center border border-gray-300 h-6 bg-white px-1 gap-0 rounded-sm hover:border-blue-400 transition-colors cursor-text overflow-hidden">
        <div class="px-1">
            <img src="public/assets/icons/folder.png" class="w-4 h-4 object-contain">
        </div>

        <div class="flex items-center h-full text-xs text-gray-700 whitespace-nowrap overflow-x-auto no-scrollbar">
            <template x-for="(crumb, index) in breadcrumbs" :key="index">
                <div class="flex items-center h-full">
                    <div class="px-1 hover:bg-blue-100 border border-transparent hover:border-blue-200 cursor-pointer flex items-center h-[20px] transition-colors select-none"
                        @click="loadPath(crumb.path)">
                        <span x-text="crumb.name"></span>
                    </div>
                    <div class="text-gray-400 px-0.5">
                        <svg class="w-3 h-3" fill="currentColor" viewBox="0 0 20 20">
                            <path fill-rule="evenodd" d="M7.293 14.707a1 1 0 010-1.414L10.586 10 7.293 6.707a1 1 0 011.414-1.414l4 4a1 1 0 010 1.414l-4 4a1 1 0 01-1.414 0z" clip-rule="evenodd"></path>
                        </svg>
                    </div>
                </div>
            </template>
        </div>

        <div class="flex-1" @click="$refs.pathInput.focus()"></div>
        <button @click="loadPath(currentPath)" class="text-gray-400 hover:text-green-600 border-l border-gray-200 pl-2 pr-1" title="Refresh">
            <svg class="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15"></path>
            </svg>
        </button>
    </div>

    <div class="w-64 flex items-center border border-gray-300 h-6 bg-white px-2 gap-2 rounded-sm">
        <input type="text" placeholder="Search..." class="w-full text-xs outline-none placeholder-gray-400 italic bg-transparent">
        <img src="public/assets/icons/preview.png" class="w-3.5 h-3.5 opacity-50">
    </div>
</div>