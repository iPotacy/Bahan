<aside class="w-full h-full overflow-y-auto bg-white select-none text-xs custom-scrollbar pb-10">

    <div class="mt-2"
        x-data="treeNode('<?= addslashes($rootPath) ?>', '<?= addslashes($rootName) ?>', 'root', true)">

        <div class="flex items-center py-1 pr-2 hover:bg-[#e5f3ff] hover:border-[#cce8ff] border border-transparent transition-colors cursor-pointer group"
            :class="isSelected ? '!bg-[#cce8ff] !border-[#99d1ff]' : ''">

            <div class="w-6 flex justify-center items-center flex-shrink-0 h-full"
                @click.stop="toggleExpand()">
                <button class="p-0.5 rounded hover:bg-gray-200 text-gray-500 transition-colors">
                    <svg class="w-3 h-3 transition-transform duration-200"
                        :class="expanded ? 'rotate-90' : ''"
                        fill="currentColor" viewBox="0 0 20 20">
                        <path fill-rule="evenodd" d="M7.293 14.707a1 1 0 010-1.414L10.586 10 7.293 6.707a1 1 0 011.414-1.414l4 4a1 1 0 010 1.414l-4 4a1 1 0 01-1.414 0z" clip-rule="evenodd"></path>
                    </svg>
                </button>
            </div>

            <div class="flex-1 flex items-center gap-1 overflow-hidden"
                @click="selectMe()">
                <?php if (strtoupper(substr(PHP_OS, 0, 3)) === 'WIN'): ?>
                    <img src="public/assets/icons/pc.png" onerror="this.src='public/assets/icons/folder.png'" class="w-4 h-4 object-contain">
                <?php else: ?>
                    <img src="public/assets/icons/hdd.png" onerror="this.src='public/assets/icons/folder.png'" class="w-4 h-4 object-contain">
                <?php endif; ?>
                <span class="font-bold truncate"><?= $rootName ?></span>
            </div>
        </div>

        <div x-show="expanded" class="flex flex-col">
            <template x-for="folder in children" :key="folder.path">
                <div class="pl-4" x-html="renderChild(folder)"></div>
            </template>
            <div x-show="loading" class="pl-8 py-1 text-gray-400 italic flex items-center gap-2">
                <div class="w-3 h-3 border-2 border-gray-400 border-t-transparent rounded-full animate-spin"></div>
                <span>Scanning...</span>
            </div>
        </div>
    </div>

</aside>

<script>
    // Tidak ada lagi Global Registry window.sidebarExpandedPaths karena kita main manual

    function treeNode(path, name, type, hasChildren = true) {
        return {
            path: path,
            name: name,
            type: type,
            expanded: false,
            loading: false,
            children: [],
            hasLoaded: false,

            projectPath: '<?= addslashes($initialPath) ?>', // Ini alamat "Rumah"
            currentPath: '<?= addslashes($initialPath) ?>', // Ini alamat sekarang

            init() {
                // 1. Root Virtual (This PC): Buka sekali saja biar tidak kosong melompong
                if (this.path === 'COMPUTER_ROOT') {
                    this.expanded = true;
                    if (!this.hasLoaded) this.fetchChildren();
                }
                // SELAIN ITU: DIAM. Tidak ada auto expand.
            },

            get isSelected() {
                if (this.path === 'COMPUTER_ROOT') return false;
                let appData = this.$root.closest('body')._x_dataStack[0];
                if (!appData || !appData.currentPath) return false;
                let myPath = this.path.replace(/\\/g, '/').toLowerCase();
                let current = appData.currentPath.replace(/\\/g, '/').toLowerCase();
                return myPath === current;
            },

            selectMe() {
                if (this.path === 'COMPUTER_ROOT') {
                    this.toggleExpand();
                    return;
                }
                this.$root.closest('body')._x_dataStack[0].loadPath(this.path);
            },

            toggleExpand() {
                this.expanded = !this.expanded;
                // Hanya fetch jika dibuka manual & belum pernah load
                if (this.expanded && !this.hasLoaded) {
                    this.fetchChildren();
                }
            },

            fetchChildren() {
                // GUARD: Jangan fetch jika file atau sedang loading
                if (this.loading || this.type === 'file') return;

                this.loading = true;

                fetch(`index.php?action=api_scan_sidebar&path=${encodeURIComponent(this.path)}`)
                    .then(res => res.json())
                    .then(data => {
                        this.children = data;
                        this.hasLoaded = true;
                        this.loading = false;
                    })
                    .catch(() => {
                        this.loading = false;
                    });
            },

            renderChild(folder) {
                // --- LOGIC FILTER SEDERHANA ---
                // Jika type nya 'file', jangan tampilkan apa-apa (return string kosong)
                if (folder.type === 'file') return '';

                const safePath = folder.path.replace(/\\/g, '\\\\').replace(/'/g, "\\'");
                const safeName = folder.name.replace(/'/g, "\\'");
                const safeType = folder.type;
                const hasChild = folder.has_children ? 'true' : 'false';

                let iconImg = 'folder.png';
                if (folder.type === 'drive') iconImg = 'hdd.png';
                // Icon file tidak perlu lagi karena file sudah di-hide

                return `
                    <div x-data="treeNode('${safePath}', '${safeName}', '${safeType}', ${hasChild})">
                        <div class="flex items-center py-1 pr-2 hover:bg-[#e5f3ff] hover:border-[#cce8ff] border border-transparent transition-colors cursor-pointer group rounded-sm"
                             :class="isSelected ? '!bg-[#cce8ff] !border-[#99d1ff]' : ''">
                            
                             <div class="w-5 flex justify-center items-center flex-shrink-0 h-full" 
                                  @click.stop="toggleExpand()">
                                  ${hasChild ? 
                                    `<button class="p-0.5 rounded hover:bg-gray-200 text-gray-500 transition-colors">
                                        <svg class="w-3 h-3 transition-transform duration-200" 
                                             :class="expanded ? 'rotate-90' : ''" 
                                             fill="currentColor" viewBox="0 0 20 20">
                                             <path fill-rule="evenodd" d="M7.293 14.707a1 1 0 010-1.414L10.586 10 7.293 6.707a1 1 0 011.414-1.414l4 4a1 1 0 010 1.414l-4 4a1 1 0 01-1.414 0z" clip-rule="evenodd"></path>
                                        </svg>
                                     </button>` 
                                    : `<div class="w-3 h-3"></div>`
                                  }
                             </div>

                            <div class="flex-1 flex items-center gap-1 overflow-hidden" 
                                 @click="selectMe()">
                                <img src="public/assets/icons/${iconImg}" onerror="this.src='public/assets/icons/folder.png'" class="w-4 h-4 object-contain">
                                <span class="truncate">${folder.name}</span>
                            </div>
                        </div>

                        <div x-show="expanded" class="flex flex-col pl-4">
                            <template x-for="child in children" :key="child.path">
                                <div x-html="renderChild(child)"></div>
                            </template>
                        </div>
                    </div>
                `;
            }
        }
    }
</script>