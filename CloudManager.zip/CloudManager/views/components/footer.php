<div class="h-6 bg-white border-t border-gray-300 flex items-center justify-between px-3 text-xs text-gray-600 select-none">

    <div class="flex items-center gap-4">
        <span x-text="items.length + ' items'">0 items</span>
        <span x-show="selectedItems.length > 0" x-text="selectedItems.length + ' item selected'"></span>
    </div>

    <p class="{$colorClass} text-[11px] tracking-wide font-light">
        Powered by <?php echo App\Core\Config::DEV_NAME; ?> <?php echo App\Core\Config::APP_VERSION; ?>
    </p>

    <div class="flex items-center gap-2">
        <button title="Normal View" class="hover:bg-gray-100 p-0.5 rounded"><svg class="w-3 h-3" fill="currentColor" viewBox="0 0 20 20">
                <path d="M5 4a2 2 0 012-2h6a2 2 0 012 2v14l-5-2.5L5 18V4z"></path>
            </svg></button>
        <button title="Grid View" class="hover:bg-gray-100 p-0.5 rounded"><svg class="w-3 h-3" fill="currentColor" viewBox="0 0 20 20">
                <path d="M5 3a2 2 0 00-2 2v2a2 2 0 002 2h2a2 2 0 002-2V5a2 2 0 00-2-2H5zM5 11a2 2 0 00-2 2v2a2 2 0 002 2h2a2 2 0 002-2v-2a2 2 0 00-2-2H5zM11 5a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2h-2a2 2 0 01-2-2V5zM11 13a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2h-2a2 2 0 01-2-2v-2z"></path>
            </svg></button>
    </div>
</div>