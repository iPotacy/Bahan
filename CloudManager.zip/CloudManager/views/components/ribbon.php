<div class="bg-[#fcfcfc] border-b border-gray-300 flex flex-col select-none shadow-sm z-10" x-data="{ activeTab: 'home' }">

    <div class="flex px-2 pt-1 bg-white border-b border-gray-200">
        <button @click="activeTab = 'home'"
            class="px-5 py-1 text-xs border-t border-l border-r rounded-t-sm mb-[-1px] relative z-10 transition-colors"
            :class="activeTab === 'home' ? 'bg-[#fcfcfc] border-gray-300 text-gray-800 font-medium' : 'border-transparent text-gray-600 hover:bg-gray-50'">
            Home
        </button>
        <!-- <button @click="activeTab = 'view'"
            class="px-5 py-1 text-xs border-t border-l border-r rounded-t-sm mb-[-1px] relative z-10 transition-colors"
            :class="activeTab === 'view' ? 'bg-[#fcfcfc] border-gray-300 text-gray-800 font-medium' : 'border-transparent text-gray-600 hover:bg-gray-50'">
            View
        </button> -->
    </div>

    <div class="h-[96px] bg-[#fcfcfc] flex items-stretch overflow-x-auto overflow-y-hidden">

        <div x-show="activeTab === 'home'" class="flex items-stretch h-full w-full px-1 gap-0.5 fade-in">
            <?php include 'ribbon/tab-home.php'; ?>
        </div>

        <!-- <div x-show="activeTab === 'view'" class="flex items-stretch h-full w-full px-1 gap-0.5 fade-in" style="display: none;">
            <?php include 'ribbon/tab-view.php'; ?>
        </div> -->

    </div>
</div>