<div class="h-8 bg-white border-b border-gray-200 flex items-center justify-between px-3 select-none z-30 relative">
    <div class="flex items-center gap-1">
        <span class="font-bold text-orange-500 text-sm">Brother</span>
        <span class="font-bold text-gray-600 text-sm">Line</span>
    </div>

    <div class="relative" x-data="{ open: false }">
        
        <div @click="open = !open" 
             class="flex items-center gap-1.5 px-2 py-0.5 rounded cursor-pointer transition-colors border border-transparent hover:bg-[#e5f3ff] hover:border-[#cce8ff]"
             :class="open ? 'bg-[#e5f3ff] border-[#cce8ff]' : ''">
            
            <div class="relative">
                 <img src="https://ui-avatars.com/api/?name=Admin&background=107c10&color=fff&size=24" class="w-4 h-4 rounded shadow-sm opacity-90">
                 <div class="absolute -bottom-0.5 -right-0.5 w-2 h-2 bg-green-500 border border-white rounded-full"></div>
            </div>
            
            <span class="text-xs font-medium text-gray-700">Administrator</span>
            
            <svg class="w-2 h-2 text-gray-500" fill="currentColor" viewBox="0 0 20 20"><path fill-rule="evenodd" d="M5.293 7.293a1 1 0 011.414 0L10 10.586l3.293-3.293a1 1 0 111.414 1.414l-4 4a1 1 0 01-1.414 0l-4-4a1 1 0 010-1.414z" clip-rule="evenodd"></path></svg>
        </div>

        <div x-show="open" 
             @click.outside="open = false"
             style="display: none;"
             class="absolute right-0 top-full mt-1 w-48 bg-white border border-gray-300 shadow-lg py-1 z-50 rounded-sm">
            
            <button @click="settingsOpen = true; open = false" class="w-full text-left flex items-center gap-3 px-3 py-1.5 hover:bg-[#e5f3ff] hover:text-black text-gray-700 text-xs">
                <div class="relative w-4 h-4">
                    <img src="https://ui-avatars.com/api/?name=Admin&background=107c10&color=fff&size=24" class="w-3.5 h-3.5 rounded opacity-80">
                    <div class="absolute bottom-0 right-0 bg-white rounded-sm border border-gray-400 w-2 h-2 flex items-center justify-center">
                        <svg class="w-1.5 h-1.5 text-black" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="4" d="M5 13l4 4L19 7"></path></svg>
                    </div>
                </div>
                User Settings
            </button>

            <div class="h-px bg-gray-200 my-1 mx-1"></div>

            <a href="index.php?action=logout" class="block w-full text-left flex items-center gap-3 px-3 py-1.5 hover:bg-[#e5f3ff] hover:text-black text-gray-700 text-xs">
                <div class="relative w-4 h-4">
                    <img src="https://ui-avatars.com/api/?name=Admin&background=107c10&color=fff&size=24" class="w-3.5 h-3.5 rounded opacity-80">
                    <div class="absolute top-1 -right-1">
                        <svg class="w-3 h-3 text-orange-600" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="3" d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1"></path></svg>
                    </div>
                </div>
                Log out
            </a>
        </div>

    </div>
</div>