<div class="flex flex-col px-1 group-container">
    <div class="flex items-start gap-0.5 h-full pt-1">
        <button class="flex flex-col items-center justify-start pt-1 w-[64px] bg-[#e5f3ff] border border-[#cce8ff] rounded-sm h-[68px]">
            <div class="w-8 h-8 bg-white border border-gray-400 flex rounded-sm">
                <div class="w-1/3 bg-[#3c8dbc] h-full"></div>
                <div class="w-2/3 bg-white h-full"></div>
            </div>
            <span class="text-[11px] text-gray-800 mt-auto pb-1 leading-tight text-center">Navigation<br>pane</span>
        </button>
    </div>
    <div class="text-[11px] text-[#888] text-center mt-auto pb-0.5">Panes</div>
</div>

<div class="ribbon-sep"></div>

<div class="flex flex-col px-1 group-container">
     <div class="grid grid-cols-2 gap-x-1 gap-y-0 h-[68px] pt-1">
         <button class="flex items-center gap-1 px-1 h-[20px] hover:bg-[#e5f3ff] hover:border-[#cce8ff] border border-transparent rounded-sm">
             <svg class="w-3.5 h-3.5 text-gray-500" fill="none" stroke="currentColor" viewBox="0 0 24 24"><rect x="3" y="3" width="7" height="7"></rect><rect x="14" y="3" width="7" height="7"></rect><rect x="3" y="14" width="7" height="7"></rect><rect x="14" y="14" width="7" height="7"></rect></svg>
             <span class="text-[11px] text-gray-600">Extra large icons</span>
         </button>
         <button class="flex items-center gap-1 px-1 h-[20px] hover:bg-[#e5f3ff] hover:border-[#cce8ff] border border-transparent rounded-sm">
             <svg class="w-3.5 h-3.5 text-gray-500" fill="none" stroke="currentColor" viewBox="0 0 24 24"><rect x="3" y="3" width="6" height="6"></rect><rect x="3" y="11" width="6" height="6"></rect><rect x="3" y="19" width="6" height="6"></rect></svg>
             <span class="text-[11px] text-gray-600">Medium icons</span>
         </button>
         <button class="flex items-center gap-1 px-1 h-[20px] hover:bg-[#e5f3ff] hover:border-[#cce8ff] border border-transparent rounded-sm">
             <svg class="w-3.5 h-3.5 text-gray-500" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6h16M4 10h16M4 14h16M4 18h16"></path></svg>
             <span class="text-[11px] text-gray-600">Details</span>
         </button>

         <button class="flex items-center gap-1 px-1 h-[20px] hover:bg-[#e5f3ff] hover:border-[#cce8ff] border border-transparent rounded-sm">
             <svg class="w-3.5 h-3.5 text-gray-500" fill="none" stroke="currentColor" viewBox="0 0 24 24"><rect x="3" y="3" width="18" height="18"></rect></svg>
             <span class="text-[11px] text-gray-600">Large icons</span>
         </button>
         <button class="flex items-center gap-1 px-1 h-[20px] hover:bg-[#e5f3ff] hover:border-[#cce8ff] border border-transparent rounded-sm">
             <svg class="w-3.5 h-3.5 text-gray-500" fill="none" stroke="currentColor" viewBox="0 0 24 24"><rect x="4" y="4" width="4" height="4"></rect><rect x="10" y="4" width="4" height="4"></rect><rect x="16" y="4" width="4" height="4"></rect></svg>
             <span class="text-[11px] text-gray-600">Small icons</span>
         </button>
         <button class="flex items-center gap-1 px-1 h-[20px] bg-[#e5f3ff] border border-[#cce8ff] rounded-sm">
             <svg class="w-3.5 h-3.5 text-gray-500" fill="none" stroke="currentColor" viewBox="0 0 24 24"><rect x="3" y="3" width="8" height="8"></rect><path d="M12 4h8M12 8h6"></path></svg>
             <span class="text-[11px] text-gray-800">Tiles</span>
         </button>
     </div>
     <div class="text-[11px] text-[#888] text-center mt-auto pb-0.5">Layout</div>
</div>

<div class="ribbon-sep"></div>

<div class="flex flex-col px-1 group-container">
    <div class="flex flex-col justify-start gap-1 h-full pt-2 px-1">
        <label class="flex items-center gap-2 cursor-pointer select-none">
            <input type="checkbox" checked class="rounded border-gray-400 text-[#3c8dbc] shadow-sm focus:ring-0 w-3.5 h-3.5">
            <span class="text-[11px] text-gray-700">File extensions</span>
        </label>
        
        </div>
    <div class="text-[11px] text-[#888] text-center mt-auto pb-0.5">Show/hide</div>
</div>

<div class="flex-1"></div>