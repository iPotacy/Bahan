<div class="flex flex-col px-1 group-container">
    <div class="flex items-start gap-0.5 h-full pt-1.5">
        <div class="flex flex-col items-center justify-center rounded select-none transition-colors py-1 w-[46px]"
            :class="selectedItems.length > 0 ? 'hover:bg-blue-100 cursor-pointer text-gray-700' : 'opacity-40 cursor-default text-gray-400'"
            @click="selectedItems.length > 0 ? copySelected() : null">
            <img src="public/assets/icons/copy.png" class="w-8 h-8 mb-1" onerror="this.style.display='none'">
            <span class="text-[10px]">Copy</span>
        </div>
        <div class="flex flex-col items-center justify-center py-1 rounded select-none transition-colors w-[46px]"
            :class="clipboard.length > 0 ? 'hover:bg-blue-100 cursor-pointer text-gray-700' : 'opacity-40 cursor-default text-gray-400'"
            @click="clipboard.length > 0 ? pasteItems() : null">
            <img src="public/assets/icons/paste.png" class="w-8 h-8 mb-1" onerror="this.style.display='none'">
            <span class="text-[10px]">Paste</span>
        </div>
        <div class="flex items-center gap-1 mt-1 px-1 py-1 hover:bg-[#e5f3ff] hover:border-[#cce8ff] border border-transparent rounded-sm h-[22px]"
            :class="selectedItems.length > 0 ? 'hover:bg-blue-100 cursor-pointer text-gray-700' : 'opacity-40 cursor-default text-gray-400'"
            @click="selectedItems.length > 0 ? cutSelected() : null">
            <img src="public/assets/icons/cut.png" class="w-3 h-3 object-contain" onerror="this.style.display='none'">
            <span class="text-[10px] text-gray-600">Cut</span>
        </div>
    </div>
    <div class="text-[11px] text-[#888] text-center mt-auto pb-0.5 border-t border-transparent">Clipboard</div>
</div>

<div class="ribbon-sep"></div>

<div class="flex flex-col px-1 group-container">
    <div class="flex items-start gap-0.5 h-full pt-1.5">
        <div class="flex flex-col items-center justify-center px-3 py-1 rounded select-none transition-colors w-[46px] h-[62px]"
            :class="selectedItems.length > 0 ? 'hover:bg-red-50 cursor-pointer text-red-600' : 'opacity-40 cursor-default text-gray-400'"
            @click="selectedItems.length > 0 ? confirmDelete() : null">
            <svg class="w-8 h-8 mb-1 text-[#d9534f]" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"></path>
            </svg>
            <span class="text-[10px] text-gray-600 mt-auto pb-1">Delete</span>
        </div>
        <div class="flex flex-col items-center justify-center px-3 py-1 rounded select-none transition-colors w-[46px] h-[62px]"
            :class="selectedItems.length === 1 ? 'hover:bg-blue-100 cursor-pointer text-gray-700' : 'opacity-40 cursor-default text-gray-400'"
            @click="triggerRename()">
            <img src="public/assets/icons/rename.png" class="w-8 h-8 mb-1 object-contain" draggable="false">
            <span class="text-[10px] text-gray-600 mt-auto pb-1">Rename</span>
        </div>
    </div>
    <div class="text-[11px] text-[#888] text-center mt-auto pb-0.5">Organize</div>
</div>

<div class="ribbon-sep"></div>

<div class="flex flex-col px-1 group-container">
    <div class="flex items-start gap-2 h-full pt-1.5">
        <div class="flex flex-col items-center justify-center px-1 py-1 rounded select-none hover:bg-blue-100 cursor-pointer text-gray-700 transition-colors"
            @click="createNewFolder()">
            <img src="public/assets/icons/folder.png" class="w-8 h-8 mb-1 object-contain" onerror="this.style.display='none'">
            <span class="text-[10px] text-gray-600 mt-auto pb-1 leading-tight text-center">New folder</span>
        </div>
        <div class="flex flex-col items-center justify-center px-1 py-1 rounded select-none hover:bg-blue-100 cursor-pointer text-gray-700 transition-colors"
            @click="createNewFile()">
            <img src="public/assets/icons/file.png" class="w-8 h-8 mb-1 object-contain" onerror="this.style.display='none'">
            <span class="text-[10px] text-gray-600 mt-auto pb-1 leading-tight text-center">New file</span>
        </div>
    </div>
    <div class="text-[11px] text-[#888] text-center mt-auto pb-0.5">New</div>
</div>

<div class="ribbon-sep"></div>

<div class="flex flex-col px-1 group-container">
    <div class="flex items-start gap-0.5 h-full pt-1.5">
        <div class="flex flex-col items-center justify-center px-3 py-1 rounded select-none transition-colors"
            :class="(selectedItems.length === 1 && selectedItems[0].type !== 'folder' && selectedItems[0].type !== 'drive') ? 'hover:bg-blue-100 cursor-pointer text-gray-700' : 'opacity-40 cursor-default text-gray-400'"
            @click="(selectedItems.length === 1 && selectedItems[0].type !== 'folder' && selectedItems[0].type !== 'drive') ? downloadItem() : null">
            <img src="public/assets/icons/download.png" class="w-8 h-8 object-contain mb-1" draggable="false">
            <span class="text-[10px] text-gray-600 mt-auto pb-1">Download</span>
        </div>
        <div class="flex flex-col items-center justify-center px-3 py-1 rounded select-none hover:bg-blue-100 cursor-pointer text-gray-700 transition-colors"
            @click="triggerUpload()">
            <img src="public/assets/icons/upload.png" class="w-8 h-8 object-contain mb-1" draggable="false">
            <span class="text-[10px] text-gray-600 mt-auto pb-1">Upload</span>
        </div>
        <div class="flex flex-col items-center justify-center px-3 py-1 rounded select-none hover:bg-blue-100 cursor-pointer text-gray-700 transition-colors"
            @click="openRemoteUpload()">
            <img src="public/assets/icons/terminal.png" class="w-8 h-8 object-contain mb-1" draggable="false">
            <span class="text-[10px] text-gray-600 mt-auto pb-1 text-center">Upload URL</span>
        </div>
    </div>
    <div class="text-[11px] text-[#888] text-center mt-auto pb-0.5">Transfer</div>
</div>

<div class="ribbon-sep"></div>

<div class="flex flex-col px-1 group-container">
    <div class="flex items-start gap-0.5 h-full pt-1.5">
        <div class="flex flex-col items-center justify-center px-3 py-1 rounded select-none transition-colors"
            :class="selectedItems.length === 1 ? 'hover:bg-blue-100 cursor-pointer text-gray-700' : 'opacity-40 cursor-default text-gray-400'"
            @click="selectedItems.length === 1 ? triggerOpen() : null">
            <img src="public/assets/icons/open.png" class="w-8 h-8 object-contain mb-1" onerror="this.style.display='none'">
            <span class="text-[10px] text-gray-600 mt-auto pb-1">Open</span>
        </div>
        <div class="flex flex-col items-center justify-center px-3 py-1 rounded select-none transition-colors"
            :class="(selectedItems.length === 1 && selectedItems[0].type !== 'folder' && selectedItems[0].type !== 'drive') ? 'hover:bg-blue-100 cursor-pointer text-gray-700' : 'opacity-40 cursor-default text-gray-400'"
            @click="(selectedItems.length === 1 && selectedItems[0].type !== 'folder' && selectedItems[0].type !== 'drive') ? openEditor('view') : null">
            <img src="public/assets/icons/preview.png" class="w-8 h-8 object-contain mb-1" onerror="this.style.display='none'">
            <span class="text-[10px] text-gray-600 mt-auto pb-1">Preview</span>
        </div>
    </div>
    <div class="text-[11px] text-[#888] text-center mt-auto pb-0.5">Open</div>
</div>

<div class="ribbon-sep"></div>

<div class="flex flex-col px-1 group-container">
    <div class="flex items-start gap-0.5 h-full pt-1">
        <div class="flex flex-col items-center justify-center px-3 py-1 rounded select-none transition-colors"
            :class="(selectedItems.length > 0 && !isSelectionZip()) ? 'hover:bg-blue-100 cursor-pointer text-gray-700' : 'opacity-40 cursor-default text-gray-400'"
            @click="(selectedItems.length > 0 && !isSelectionZip()) ? openZipModal() : null">
            <img src="public/assets/icons/zip.png" class="w-8 h-8 object-contain mb-1" onerror="this.style.display='none'">
            <span class="text-[10px] text-center leading-tight">Add to<br>zip</span>
        </div>
        <div class="flex flex-col items-center justify-center px-3 py-1 rounded select-none transition-colors"
            :class="isSelectionZip() ? 'hover:bg-blue-100 cursor-pointer text-gray-700' : 'opacity-40 cursor-default text-gray-400'"
            @click="isSelectionZip() ? openExtractModal() : null">
            <img src="public/assets/icons/unzip.png" class="w-8 h-8 object-contain mb-1" onerror="this.style.display='none'">
            <span class="text-[10px] text-center leading-tight">Extract<br>zip</span>
        </div>
    </div>
    <div class="text-[11px] text-[#888] text-center mt-auto pb-0.5">Compression</div>
</div>

<div class="ribbon-sep"></div>

<div class="flex flex-col px-1 group-container">
    <div class="flex items-center px-2 space-x-1 h-full">
        <div class="flex flex-col items-center justify-center px-3 py-1 rounded select-none hover:bg-red-50 cursor-pointer text-red-700 transition-colors"
            @click="openSecurityScanner('shell')">
            <svg class="w-5 h-5 mb-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"></path>
            </svg>
            <span class="text-[10px]">Scan Shell</span>
        </div>

        <div class="flex flex-col items-center justify-center px-3 py-1 rounded select-none hover:bg-red-50 cursor-pointer text-red-700 transition-colors"
            @click="openSecurityScanner('crontab')">
            <svg class="w-5 h-5 mb-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"></path>
            </svg>
            <span class="text-[10px]">Check Cron</span>
        </div>

        <div class="flex flex-col items-center justify-center px-3 py-1 rounded select-none hover:bg-red-50 cursor-pointer text-red-700 transition-colors"
            @click="openSecurityScanner('gsocket')">
            <svg class="w-5 h-5 mb-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 10V3L4 14h7v7l9-11h-7z"></path>
            </svg>
            <span class="text-[10px]">GSocket</span>
        </div>

        <div class="flex flex-col items-center justify-center px-3 py-1 rounded select-none hover:bg-red-50 cursor-pointer text-red-700 transition-colors"
            @click="openSecurityScanner('startup')">
            <svg class="w-5 h-5 mb-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 10V3L4 14h7v7l9-11h-7z"></path>
            </svg>
            <span class="text-[10px]">Startup</span>
        </div>
    </div>
    <div class="text-[11px] text-[#888] text-center mt-auto pb-0.5">Scanner</div>
</div>

<div class="ribbon-sep"></div>

<!-- <div class="flex flex-col px-1 group-container">
    <div class="flex flex-col justify-start gap-0.5 h-full pt-1">
        <button class="flex items-center gap-1.5 px-1 hover:bg-[#e5f3ff] hover:border-[#cce8ff] border border-transparent rounded-sm h-[22px]">
            <svg class="w-3.5 h-3.5 text-[#3c8dbc]" fill="currentColor" viewBox="0 0 20 20">
                <path fill-rule="evenodd" d="M12.586 4.586a2 2 0 112.828 2.828l-3 3a2 2 0 01-2.828 0 1 1 0 00-1.414 1.414 4 4 0 005.656 0l3-3a4 4 0 00-5.656-5.656l-1.5 1.5a1 1 0 101.414 1.414l1.5-1.5zm-5 5a2 2 0 012.828 0 1 1 0 101.414-1.414 4 4 0 00-5.656 0l-3 3a4 4 0 105.656 5.656l1.5-1.5a1 1 0 10-1.414-1.414l-1.5 1.5a2 2 0 11-2.828-2.828l3-3z" clip-rule="evenodd"></path>
            </svg>
            <span class="text-[11px] text-gray-600">View public link</span>
        </button>
    </div>
    <div class="text-[11px] text-[#888] text-center mt-auto pb-0.5">Share</div>
</div> -->

<div class="flex-1"></div>