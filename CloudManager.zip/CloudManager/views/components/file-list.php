<main class="flex-1 flex flex-col overflow-hidden bg-white relative"
    @click="selectedItems = []"
    @contextmenu.prevent="selectedItems = []; openContextMenu($event)"
    x-data="{ 
          wName: 300, wDate: 140, wType: 100, wPerms: 120, wSize: 100,
          resizing: null, startX: 0, startWidth: 0,
          startResize(col, event) { 
              this.resizing = col; 
              this.startX = event.clientX; 
              this.startWidth = this[col]; 
              document.body.style.cursor = 'col-resize'; 
          },
          performResize(event) { 
              if (this.resizing) { 
                  let diff = event.clientX - this.startX; 
                  this[this.resizing] = Math.max(50, this.startWidth + diff); 
              } 
          },
          stopResize() { 
              this.resizing = null; 
              document.body.style.cursor = 'default'; 
          }
      }"
    @mousemove.window="performResize($event)"
    @mouseup.window="stopResize()">

    <div class="flex-none bg-white border-b border-gray-300 z-10 overflow-hidden">
        <table class="w-auto text-left border-collapse select-none table-fixed">
            <colgroup>
                <col width="30">
                <col :style="{ width: wName + 'px' }">
                <col :style="{ width: wDate + 'px' }">
                <col :style="{ width: wType + 'px' }">
                <col :style="{ width: wPerms + 'px' }">
                <col :style="{ width: wSize + 'px' }">
            </colgroup>
            <thead>
                <tr class="text-xs text-gray-500 h-7 select-none">
                    <th class="font-normal border-r border-gray-200 text-center pl-2"></th>

                    <th class="relative font-normal pl-2 border-r border-gray-200 hover:bg-gray-100 cursor-pointer text-blue-600 group">Name <span class="text-[10px]">▲</span>
                        <div class="absolute right-0 top-0 w-1 h-full cursor-col-resize hover:bg-gray-400 z-20" @mousedown.stop="startResize('wName', $event)"></div>
                    </th>

                    <th class="relative font-normal pl-2 border-r border-gray-200 hover:bg-gray-100 cursor-pointer group">Date modified
                        <div class="absolute right-0 top-0 w-1 h-full cursor-col-resize hover:bg-gray-400 z-20" @mousedown.stop="startResize('wDate', $event)"></div>
                    </th>

                    <th class="relative font-normal pl-2 border-r border-gray-200 hover:bg-gray-100 cursor-pointer group">Type
                        <div class="absolute right-0 top-0 w-1 h-full cursor-col-resize hover:bg-gray-400 z-20" @mousedown.stop="startResize('wType', $event)"></div>
                    </th>

                    <th class="relative font-normal pl-2 border-r border-gray-200 hover:bg-gray-100 cursor-pointer group"
                        @click="sortBy = 'perms'; sortDesc = !sortDesc">
                        Permissions
                        <div class="absolute right-0 top-0 w-1 h-full cursor-col-resize hover:bg-gray-400 z-20" @mousedown.stop="startResize('wPerms', $event)"></div>
                    </th>

                    <th class="relative font-normal pl-2 border-r border-gray-200 hover:bg-gray-100 cursor-pointer text-right pr-2 group">Size
                        <div class="absolute right-0 top-0 w-1 h-full cursor-col-resize hover:bg-gray-400 z-20" @mousedown.stop="startResize('wSize', $event)"></div>
                    </th>

                </tr>
            </thead>
        </table>
    </div>

    <div class="flex-1 overflow-auto custom-scrollbar w-full h-full relative"
        @click.self="selectedItems = []"
        @contextmenu.prevent.self="selectedItems = []; openContextMenu($event)">

        <table class="w-auto text-left border-collapse select-none table-fixed">
            <colgroup>
                <col style="width: 30px;">
                <col :style="{ width: wName + 'px' }">
                <col :style="{ width: wDate + 'px' }">
                <col :style="{ width: wType + 'px' }">
                <col :style="{ width: wPerms + 'px' }">
                <col :style="{ width: wSize + 'px' }">
            </colgroup>
            <tbody class="text-xs text-gray-700">
                <template x-for="item in items" :key="item.path">
                    <tr class="file-row cursor-default border-b border-transparent hover:bg-[#e5f3ff] hover:border-[#cce8ff] h-6"
                        :class="[
                            isSelected(item) ? '!bg-[#cce8ff] !border-[#99d1ff]' : '',
                            isInClipboard(item.path) ? 'opacity-50 grayscale' : '' 
                        ]"
                        @click.stop="selectItem(item)"
                        @dblclick="if(item.has_children || item.type === 'folder' || item.type === 'drive') loadPath(item.path)"

                        @contextmenu.prevent.stop="selectItem(item); openContextMenu($event)">

                        <td class="text-center">
                            <img :src="item.type === 'drive' ? 'public/assets/icons/hdd.png' : (item.type === 'folder' ? 'public/assets/icons/folder.png' : 'public/assets/icons/file.png')"
                                onerror="this.src='public/assets/icons/file.png'" class="w-4 h-4 object-contain inline">
                        </td>

                        <td class="pl-2 pr-2">
                            <template x-if="renamingPath !== item.path">
                                <span class="truncate block" x-text="item.name"></span>
                            </template>

                            <template x-if="renamingPath === item.path">
                                <div class="flex items-center" @click.stop>
                                    <input type="text"
                                        class="w-full px-1 py-0.5 text-xs border border-blue-500 rounded outline-none shadow-sm bg-white text-gray-800"
                                        x-model="tempName"
                                        @keydown.enter.prevent="submitRename()"
                                        @keydown.escape="cancelRename()"
                                        @blur="submitRename()"
                                        x-init="$nextTick(() => { $el.focus(); $el.select(); })">
                                </div>
                            </template>
                        </td>

                        <td class="pl-2 text-gray-500 truncate" x-text="item.date"></td>

                        <td class="pl-2 text-gray-500 truncate" x-text="item.ext"></td>

                        <td class="py-2 px-4">
                            <div class="flex gap-1 flex-wrap">
                                <template x-for="perm in item.perms">
                                    <span class="text-[10px] font-bold"
                                        :class="{
                                            'text-green-700': perm === 'Read',
                                            'text-blue-700': perm === 'Edit',
                                            'text-red-700': perm === 'Delete',
                                            'text-gray-600': perm === 'Locked'
                                        }"
                                        x-text="perm">
                                    </span>
                                </template>
                            </div>
                        </td>

                        <td class="text-right text-gray-500 truncate pr-2" x-text="item.size"></td>

                    </tr>
                </template>
                <tr x-show="items.length === 0 && !loading">
                    <td colspan="6" class="py-10 text-center text-gray-400 italic">This folder is empty.</td>
                </tr>
            </tbody>
        </table>
        <div @click="selectedItems = []"></div>
    </div>

    <input type="file" id="fileUploadInput" class="hidden" multiple @change="handleUpload($event)">

    <div x-show="contextMenu.open"
        @click.outside="contextMenu.open = false"
        @click.stop
        class="fixed bg-[#f9f9f9] border border-gray-300 shadow-lg rounded-sm py-1 z-50 w-48 text-xs select-none"
        :style="'top: ' + contextMenu.y + 'px; left: ' + contextMenu.x + 'px;'"
        style="display: none;">

        <div @click="refresh()" class="flex items-center gap-3 px-3 py-1.5 hover:bg-[#e5f3ff] cursor-pointer text-gray-700">
            <img src="public/assets/icons/refresh.png" class="w-4 h-4 object-contain" onerror="this.style.display='none'"><span>Refresh</span>
        </div>
        <div class="h-[1px] bg-gray-200 my-1 mx-1"></div>

        <template x-if="selectedItems.length === 0">
            <div>
                <div @click="triggerUpload()" class="flex items-center gap-3 px-3 py-1.5 hover:bg-[#e5f3ff] cursor-pointer text-gray-700">
                    <img src="public/assets/icons/upload.png" class="w-4 h-4 object-contain">
                    <span>Upload</span>
                </div>

                <div @click="openRemoteUpload()" class="flex items-center gap-3 px-3 py-1.5 hover:bg-[#e5f3ff] cursor-pointer text-gray-700">
                    <svg class="w-4 h-4 text-gray-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M7 16a4 4 0 01-.88-7.903A5 5 0 1115.9 6L16 6a5 5 0 011 9.9M15 13l-3-3m0 0l-3 3m3-3v12" />
                    </svg>
                    <span>Remote Upload (URL)</span>
                </div>

                <div @click="clipboard.length > 0 ? pasteItems() : null"
                    class="flex items-center gap-3 px-3 py-1.5 transition-colors"
                    :class="clipboard.length > 0 ? 'hover:bg-[#e5f3ff] cursor-pointer text-gray-700' : 'text-gray-400 cursor-default opacity-50'">
                    <svg class="w-4 h-4" :class="clipboard.length > 0 ? 'text-gray-600' : 'text-gray-400'" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2" />
                    </svg>
                    <span>Paste</span>
                    <span x-show="clipboard.length > 0" class="ml-auto text-[10px] bg-blue-100 text-blue-600 px-1.5 rounded-full" x-text="clipboard.length"></span>
                </div>

                <div class="h-[1px] bg-gray-200 my-1 mx-1"></div>

                <div @click="createNewFolder()" class="flex items-center gap-3 px-3 py-1.5 hover:bg-[#e5f3ff] cursor-pointer text-gray-700">
                    <img src="public/assets/icons/folder.png" class="w-4 h-4 object-contain">
                    <span>New folder</span>
                </div>

                <div @click="createNewFile()" class="flex items-center gap-3 px-3 py-1.5 hover:bg-[#e5f3ff] cursor-pointer text-gray-700">
                    <img src="public/assets/icons/file.png" class="w-4 h-4 object-contain">
                    <span>New file</span>
                </div>
            </div>
        </template>

        <template x-if="selectedItems.length > 0">
            <div>
                <template x-if="selectedItems[0].type !== 'folder' && selectedItems[0].type !== 'drive'">
                    <div>
                        <template x-if="!isBinaryFile(selectedItems[0].name)">
                            <div>
                                <template x-if="hasPerm('Read')">
                                    <div @click="openEditor('view')" class="flex items-center gap-3 px-3 py-1.5 hover:bg-[#e5f3ff] cursor-pointer text-gray-700">
                                        <svg class="w-4 h-4 text-gray-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
                                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z" />
                                        </svg>
                                        <span>View</span>
                                    </div>
                                </template>
                                <template x-if="hasPerm('Edit')">
                                    <div @click="openEditor('edit')" class="flex items-center gap-3 px-3 py-1.5 hover:bg-[#e5f3ff] cursor-pointer text-gray-700">
                                        <svg class="w-4 h-4 text-gray-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15.232 5.232l3.536 3.536m-2.036-5.036a2.5 2.5 0 113.536 3.536L6.5 21.036H3v-3.572L16.732 3.732z" />
                                        </svg>
                                        <span>Edit</span>
                                    </div>
                                </template>
                            </div>
                        </template>

                        <template x-if="hasPerm('Read')">
                            <div @click="downloadItem()" class="flex items-center gap-3 px-3 py-1.5 hover:bg-[#e5f3ff] cursor-pointer text-gray-700">
                                <svg class="w-4 h-4 text-gray-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4" />
                                </svg>
                                <span>Download</span>
                            </div>
                        </template>
                        <div class="h-[1px] bg-gray-200 my-1 mx-1"></div>
                    </div>
                </template>

                <template x-if="hasPerm('Read')">
                    <div @click="copySelected()" class="flex items-center gap-3 px-3 py-1.5 hover:bg-[#e5f3ff] cursor-pointer text-gray-700">
                        <svg class="w-4 h-4 text-gray-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 16H6a2 2 0 01-2-2V6a2 2 0 012-2h8a2 2 0 012 2v2m-6 12h8a2 2 0 002-2v-8a2 2 0 00-2-2h-8a2 2 0 00-2 2v8a2 2 0 002 2z" />
                        </svg>
                        <span>Copy</span>
                    </div>
                </template>

                <template x-if="hasPerm('Delete')">
                    <div @click="renameItem()" class="flex items-center gap-3 px-3 py-1.5 hover:bg-[#e5f3ff] cursor-pointer text-gray-700">
                        <svg class="w-4 h-4 text-gray-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z" />
                        </svg>
                        <span>Rename</span>
                    </div>
                </template>

                <div class="h-[1px] bg-gray-200 my-1 mx-1"></div>

                <template x-if="hasPerm('Delete')">
                    <div @click="confirmDelete()" class="flex items-center gap-3 px-3 py-1.5 hover:bg-[#e5f3ff] cursor-pointer text-gray-700">
                        <svg class="w-4 h-4 text-red-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
                        </svg>
                        <span>Delete</span>
                    </div>
                </template>
            </div>
        </template>
    </div>

    <div x-show="loading" class="absolute inset-0 bg-white bg-opacity-50 flex justify-center items-center z-40">
        <div class="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
    </div>
</main>