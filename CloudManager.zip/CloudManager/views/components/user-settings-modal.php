<div x-show="settingsOpen" 
     style="display: none;"
     class="fixed inset-0 z-50 flex items-center justify-center bg-black/20 backdrop-blur-[1px]">
    
    <div class="w-[380px] bg-[#f0f0f0] border border-gray-400 shadow-2xl rounded-sm flex flex-col font-sans"
         x-data="{ changePass: false, p1: '', p2: '' }"
         x-init="$watch('settingsOpen', value => {
             if(value) {
                 // Reset semua form saat modal dibuka
                 changePass = false;
                 p1 = '';
                 p2 = '';
             }
         })">
        
        <div class="flex items-center justify-between px-3 py-2 bg-white border-b border-gray-200">
            <span class="text-sm font-medium text-gray-800">User Settings</span>
            <button @click="settingsOpen = false" class="text-gray-500 hover:text-red-600 hover:bg-gray-100 p-0.5 rounded">
                <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"></path></svg>
            </button>
        </div>

        <form method="POST" action="index.php?action=change_password" class="p-4 flex flex-col gap-4">
            
            <div class="flex w-fit items-center gap-2 select-none cursor-pointer" 
                 @click="changePass = !changePass; if(!changePass){ p1=''; p2=''; }">
                <input type="checkbox" x-model="changePass" class="rounded border-gray-300 text-blue-600 shadow-sm focus:ring-0 cursor-pointer pointer-events-none">
                <label class="text-xs text-gray-700 cursor-pointer">Change password</label>
            </div>

            <div class="pl-6 flex flex-col gap-3">
                
                <div class="grid grid-cols-[110px_1fr] items-center gap-2">
                    <label class="text-xs text-gray-600" :class="!changePass ? 'opacity-50' : ''">Password:</label>
                    <input type="password" name="password" x-model="p1"
                           class="h-6 px-2 text-xs border border-gray-300 rounded-sm outline-none w-full shadow-sm transition-colors"
                           :class="!changePass ? 'bg-gray-200 text-gray-400 cursor-not-allowed select-none' : 'bg-white focus:border-blue-400 focus:ring-1 focus:ring-blue-200'"
                           :disabled="!changePass"
                           :required="changePass">
                </div>

                <div class="grid grid-cols-[110px_1fr] items-center gap-2">
                    <label class="text-xs text-gray-600" :class="!changePass ? 'opacity-50' : ''">Confirm Password:</label>
                    <input type="password" name="confirm_password" x-model="p2"
                           class="h-6 px-2 text-xs border border-gray-300 rounded-sm outline-none w-full shadow-sm transition-colors"
                           :class="!changePass ? 'bg-gray-200 text-gray-400 cursor-not-allowed select-none' : 'bg-white focus:border-blue-400 focus:ring-1 focus:ring-blue-200'"
                           :disabled="!changePass"
                           :required="changePass">
                </div>

                <div class="pl-[118px] min-h-[13px] flex flex-col gap-1">
                    
                    <span x-show="changePass && p2.length > 0 && p1 !== p2" 
                          style="display: none;"
                          class="text-[10px] text-red-600 flex items-center gap-1">
                        <svg class="w-3 h-3" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z"></path></svg>
                        Passwords do not match!
                    </span>

                    <span x-show="changePass && p1.length > 0 && p1.length < 6" 
                          style="display: none;"
                          class="text-[10px] text-orange-600 flex items-center gap-1">
                        <svg class="w-3 h-3" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"></path></svg>
                        Min. 6 characters required!
                    </span>
                </div>
            </div>

            <div class="flex justify-end gap-2 pt-3 border-t border-gray-300/50">
                <button type="submit" 
                        class="px-5 py-1 text-xs border rounded-sm shadow-sm transition-colors min-w-[70px]"
                        :class="(changePass && p1 === p2 && p1.length >= 6) ? 'bg-white border-gray-300 hover:bg-blue-50 hover:border-blue-300 text-gray-700' : 'bg-gray-100 border-gray-300 text-gray-400 cursor-default'"
                        :disabled="!changePass || p1 !== p2 || p1.length < 6"> 
                    OK
                </button>
                
                <button type="button" @click="settingsOpen = false" class="px-5 py-1 text-xs bg-white border border-gray-300 hover:bg-gray-50 rounded-sm shadow-sm transition-colors text-gray-700 min-w-[70px]">
                    Cancel
                </button>
            </div>

        </form>
    </div>
</div>