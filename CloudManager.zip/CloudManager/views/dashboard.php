<!DOCTYPE html>
<html lang="en" class="h-full bg-white">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard - <?= \App\Core\Config::APP_NAME ?></title>

    <script src="https://cdn.tailwindcss.com"></script>
    <script defer src="https://cdn.jsdelivr.net/npm/alpinejs@3.13.3/dist/cdn.min.js"></script>

    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600&display=swap" rel="stylesheet">

    <style>
        /* Paksa semua elemen menggunakan Inter & ukuran font mirip desktop app */
        body {
            font-family: 'Inter', sans-serif;
            font-size: 12px;
        }

        /* Utility khusus untuk Ribbon Separator */
        .ribbon-sep {
            width: 1px;
            height: 100%;
            background: #e5e7eb;
            margin: 0 6px;
        }

        /* Custom Scrollbar tipis */
        ::-webkit-scrollbar {
            width: 8px;
            height: 8px;
        }

        ::-webkit-scrollbar-thumb {
            background: #cbd5e1;
            border-radius: 4px;
        }

        ::-webkit-scrollbar-track {
            background: transparent;
        }

        /* Table Zebra Striping */
        .file-row:nth-child(even) {
            background-color: #f8fafc;
        }

        [x-cloak] {
            display: none !important;
        }
    </style>
</head>

<body class="h-full flex flex-col overflow-hidden text-gray-700" x-data="fileManager()">

    <?php include 'components/header.php'; ?>
    <?php include 'components/ribbon.php'; ?>
    <?php include 'components/address-bar.php'; ?>
    <div class="flex-1 flex overflow-hidden" x-data="{ sidebarWidth: 260, resizing: false }">
        <div class="flex-shrink-0 bg-white h-full relative"
            :style="'width: ' + sidebarWidth + 'px'">
            <?php include 'components/sidebar.php'; ?>
            <div class="absolute top-0 right-0 w-1 h-full cursor-col-resize hover:bg-blue-400 z-50 transition-colors"
                :class="resizing ? 'bg-blue-600' : 'bg-transparent'"
                @mousedown="resizing = true; startX = $event.clientX; startWidth = sidebarWidth"
                @mouseup.window="resizing = false"
                @mousemove.window="if(resizing) { sidebarWidth = Math.max(150, startWidth + ($event.clientX - startX)); }">
            </div>

            <div class="absolute top-0 right-0 w-[1px] h-full bg-gray-300 pointer-events-none"></div>
        </div>

        <div class="flex-1 overflow-hidden flex flex-col min-w-0 bg-white">
            <?php include 'components/file-list.php'; ?>
        </div>
    </div>
    <?php include 'components/footer.php'; ?>
    <?php include 'components/user-settings-modal.php'; ?>

    <div x-show="newFolderModal.open"
        style="display: none;"
        class="fixed inset-0 z-[60] flex items-center justify-center bg-black/20 backdrop-blur-[1px]"
        x-transition.opacity>

        <div class="bg-white rounded-lg shadow-2xl w-96 border border-gray-200 overflow-hidden transform transition-all"
            @click.outside="newFolderModal.open = false"
            @keydown.escape.window="newFolderModal.open = false">

            <div class="px-4 py-3 border-b border-gray-100 flex justify-between items-center bg-gray-50">
                <h3 class="font-medium text-gray-700 text-sm">Create New Folder</h3>
                <button @click="newFolderModal.open = false" class="text-gray-400 hover:text-red-500">
                    <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"></path>
                    </svg>
                </button>
            </div>

            <div class="p-5">
                <label class="block text-xs text-gray-500 mb-2">Folder Name:</label>
                <div class="flex items-center border border-blue-400 rounded-sm overflow-hidden ring-2 ring-blue-100">
                    <div class="bg-gray-50 px-3 py-2 border-r border-gray-200">
                        <img src="public/assets/icons/folder.png" class="w-5 h-5 object-contain">
                    </div>
                    <input type="text"
                        x-ref="folderInput"
                        x-model="newFolderModal.name"
                        @keydown.enter="submitNewFolder()"
                        class="w-full px-3 py-2 text-sm outline-none text-gray-700"
                        placeholder="Type folder name...">
                </div>
                <p class="text-[10px] text-gray-400 mt-2">Invalid characters: \ / : * ? " <> |</p>
            </div>

            <div class="px-4 py-3 bg-gray-50 flex justify-end gap-2 border-t border-gray-100">
                <button @click="newFolderModal.open = false"
                    class="px-4 py-1.5 text-xs font-medium text-gray-600 bg-white border border-gray-300 rounded hover:bg-gray-100 transition-colors">
                    Cancel
                </button>
                <button @click="submitNewFolder()"
                    class="px-4 py-1.5 text-xs font-medium text-white bg-blue-600 border border-blue-600 rounded hover:bg-blue-700 shadow-sm transition-colors flex items-center gap-2"
                    :disabled="loading"
                    :class="loading ? 'opacity-70 cursor-not-allowed' : ''">
                    <span x-show="loading" class="animate-spin h-3 w-3 border-2 border-white border-t-transparent rounded-full"></span>
                    Create
                </button>
            </div>
        </div>
    </div>

    <div x-show="newFileModal.open"
        style="display: none;"
        class="fixed inset-0 z-[60] flex items-center justify-center bg-black/20 backdrop-blur-[1px]"
        x-transition.opacity>

        <div class="bg-white rounded-lg shadow-2xl w-96 border border-gray-200 overflow-hidden transform transition-all"
            @click.outside="newFileModal.open = false"
            @keydown.escape.window="newFileModal.open = false">

            <div class="px-4 py-3 border-b border-gray-100 flex justify-between items-center bg-gray-50">
                <h3 class="font-medium text-gray-700 text-sm">Create New File</h3>
                <button @click="newFileModal.open = false" class="text-gray-400 hover:text-red-500">
                    <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"></path>
                    </svg>
                </button>
            </div>

            <div class="p-5">
                <label class="block text-xs text-gray-500 mb-2">File Name (with extension):</label>
                <div class="flex items-center border border-blue-400 rounded-sm overflow-hidden ring-2 ring-blue-100">
                    <div class="bg-gray-50 px-3 py-2 border-r border-gray-200">
                        <img src="public/assets/icons/file.png" class="w-5 h-5 object-contain">
                    </div>
                    <input type="text"
                        x-ref="fileInput"
                        x-model="newFileModal.name"
                        @keydown.enter="submitNewFile()"
                        class="w-full px-3 py-2 text-sm outline-none text-gray-700"
                        placeholder="example.txt">
                </div>
                <p class="text-[10px] text-gray-400 mt-2">Example: script.php, notes.txt, style.css</p>
            </div>

            <div class="px-4 py-3 bg-gray-50 flex justify-end gap-2 border-t border-gray-100">
                <button @click="newFileModal.open = false"
                    class="px-4 py-1.5 text-xs font-medium text-gray-600 bg-white border border-gray-300 rounded hover:bg-gray-100 transition-colors">
                    Cancel
                </button>
                <button @click="submitNewFile()"
                    class="px-4 py-1.5 text-xs font-medium text-white bg-blue-600 border border-blue-600 rounded hover:bg-blue-700 shadow-sm transition-colors flex items-center gap-2"
                    :disabled="loading"
                    :class="loading ? 'opacity-70 cursor-not-allowed' : ''">
                    <span x-show="loading" class="animate-spin h-3 w-3 border-2 border-white border-t-transparent rounded-full"></span>
                    Create File
                </button>
            </div>
        </div>
    </div>

    <div x-show="deleteModal.open"
        style="display: none;"
        class="fixed inset-0 z-[70] flex items-center justify-center bg-black/20 backdrop-blur-[1px]"
        x-transition.opacity>

        <div class="bg-white rounded-lg shadow-2xl w-96 border border-gray-200 overflow-hidden transform transition-all"
            @click.outside="deleteModal.open = false"
            @keydown.escape.window="deleteModal.open = false">

            <div class="px-4 py-3 border-b border-red-100 flex justify-between items-center bg-red-50">
                <h3 class="font-medium text-red-700 text-sm flex items-center gap-2">
                    <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z"></path>
                    </svg>
                    Confirm Deletion
                </h3>
                <button @click="deleteModal.open = false" class="text-red-400 hover:text-red-600">
                    <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"></path>
                    </svg>
                </button>
            </div>

            <div class="p-5 text-center">
                <div class="w-12 h-12 rounded-full bg-red-100 flex items-center justify-center mx-auto mb-3">
                    <svg class="w-6 h-6 text-red-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"></path>
                    </svg>
                </div>

                <p class="text-sm text-gray-700 font-medium">Are you sure you want to delete?</p>
                <p class="text-xs text-gray-500 mt-1" x-text="deleteModal.message"></p>
                <p class="text-[10px] text-red-500 mt-3 font-semibold">This action cannot be undone!</p>
            </div>

            <div class="px-4 py-3 bg-gray-50 flex justify-end gap-2 border-t border-gray-100">
                <button @click="deleteModal.open = false"
                    class="px-4 py-1.5 text-xs font-medium text-gray-600 bg-white border border-gray-300 rounded hover:bg-gray-100 transition-colors">
                    Cancel
                </button>
                <button @click="submitDelete()"
                    class="px-4 py-1.5 text-xs font-medium text-white bg-red-600 border border-red-600 rounded hover:bg-red-700 shadow-sm transition-colors flex items-center gap-2"
                    :disabled="loading"
                    :class="loading ? 'opacity-70 cursor-not-allowed' : ''">
                    <span x-show="loading" class="animate-spin h-3 w-3 border-2 border-white border-t-transparent rounded-full"></span>
                    Delete Permanently
                </button>
            </div>
        </div>
    </div>

    <div x-show="editorModal.open"
        style="display: none;"
        class="fixed inset-0 z-[70] flex items-center justify-center bg-black/50 backdrop-blur-sm"
        x-transition.opacity>

        <div class="bg-white w-[90%] h-[90%] flex flex-col rounded shadow-2xl overflow-hidden">

            <div class="flex justify-between items-center px-4 py-2 border-b border-gray-200 bg-gray-50">
                <div class="flex items-center gap-2">
                    <span class="font-bold text-gray-700 text-sm" x-text="editorModal.filename"></span>
                    <span x-show="editorModal.mode === 'view'" class="text-[10px] bg-gray-200 text-gray-600 px-2 py-0.5 rounded">READ ONLY</span>
                    <span x-show="editorModal.mode === 'edit'" class="text-[10px] bg-blue-100 text-blue-600 px-2 py-0.5 rounded">EDIT MODE</span>
                </div>
                <button @click="editorModal.open = false; if(editorModal.fromScanner){ securityModal.open = true; editorModal.fromScanner = false; }" class="text-gray-500 hover:text-red-500">
                    <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"></path>
                    </svg>
                </button>
            </div>

            <div class="flex-1 relative">
                <textarea x-model="editorModal.content"
                    class="w-full h-full p-4 font-mono text-sm outline-none resize-none bg-[#1e1e1e] text-[#d4d4d4]"
                    :readonly="editorModal.mode === 'view'"></textarea>
            </div>

            <div class="px-4 py-2 border-t border-gray-200 bg-gray-50 flex justify-end gap-2">
                <button @click="editorModal.open = false; if(editorModal.fromScanner){ securityModal.open = true; editorModal.fromScanner = false; }" class="px-4 py-1 text-xs font-medium text-gray-600 border border-gray-300 rounded hover:bg-gray-100">Close</button>

                <button x-show="editorModal.mode === 'edit'"
                    @click="saveFileContent()"
                    class="px-4 py-1 text-xs font-medium text-white bg-blue-600 rounded hover:bg-blue-700 flex items-center gap-2">
                    <svg class="w-3 h-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 7H5a2 2 0 00-2 2v9a2 2 0 002 2h14a2 2 0 002-2V9a2 2 0 00-2-2h-3m-1 4l-3 3m0 0l-3-3m3 3V4"></path>
                    </svg>
                    Save Changes
                </button>
            </div>
        </div>
    </div>

    <div x-show="toast.show"
        style="display: none;"
        x-transition:enter="transition ease-out duration-300"
        x-transition:enter-start="opacity-0 -translate-y-10"
        x-transition:enter-end="opacity-100 translate-y-0"
        x-transition:leave="transition ease-in duration-200"
        x-transition:leave-start="opacity-100 translate-y-0"
        x-transition:leave-end="opacity-0 -translate-y-10"
        class="fixed top-5 left-1/2 transform -translate-x-1/2 z-[100] flex items-center gap-3 px-4 py-3 bg-white rounded shadow-2xl border-l-4 min-w-[320px] max-w-[90%]"
        :class="toast.type === 'success' ? 'border-green-500' : 'border-red-500'">

        <div x-show="toast.type === 'success'" class="text-green-500 bg-green-100 p-1.5 rounded-full shrink-0">
            <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"></path>
            </svg>
        </div>

        <div x-show="toast.type === 'error'" class="text-red-500 bg-red-100 p-1.5 rounded-full shrink-0">
            <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"></path>
            </svg>
        </div>

        <div class="flex-1 min-w-0">
            <h4 class="text-xs font-bold text-gray-800 truncate" x-text="toast.type === 'success' ? 'Success' : 'Error'"></h4>
            <p class="text-xs text-gray-600 mt-0.5 break-words leading-tight" x-text="toast.message"></p>
        </div>

        <button @click="toast.show = false" class="text-gray-400 hover:text-gray-600 shrink-0 ml-2">
            <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"></path>
            </svg>
        </button>
    </div>

    <div x-show="remoteModal.open"
        style="display: none;"
        class="fixed inset-0 z-[80] flex items-center justify-center bg-black/50 backdrop-blur-sm"
        x-transition.opacity>

        <div class="bg-[#1e1e1e] w-[600px] rounded-lg shadow-2xl border border-gray-700 overflow-hidden font-mono text-sm flex flex-col"
            @click.outside="remoteModal.open = false">

            <div class="px-4 py-2 bg-[#2d2d2d] border-b border-gray-700 flex justify-between items-center select-none">
                <div class="flex items-center gap-2">
                    <div class="flex gap-1.5">
                        <div class="w-3 h-3 rounded-full bg-red-500"></div>
                        <div class="w-3 h-3 rounded-full bg-yellow-500"></div>
                        <div class="w-3 h-3 rounded-full bg-green-500"></div>
                    </div>
                    <span class="text-gray-400 ml-2 font-bold text-xs">root@server:~ (Remote Upload)</span>
                </div>
                <button @click="remoteModal.open = false" class="text-gray-500 hover:text-white">✕</button>
            </div>

            <div class="p-4 h-[350px] overflow-y-auto custom-scrollbar flex flex-col bg-[#0c0c0c] text-green-500" id="terminalOutput">

                <div class="opacity-70 mb-4 border-b border-green-900 pb-2 select-none">
                    <p>CLOUD MANAGER TERMINAL v2.0</p>
                    <p>=========================================</p>
                    <p>Available Methods:</p>
                    <p>1. <span class="text-white font-bold">curl</span> [url] -> Standard Library (Recommended)</p>
                    <p>2. <span class="text-white font-bold">wget</span> [url] -> Uses file_get_contents (Stream)</p>
                    <p>3. <span class="text-white font-bold">socket</span> [url] -> Raw TCP Connection (Bypass WAF)</p>
                    <p>-----------------------------------------</p>
                    <p class="italic text-gray-500">Tip: You can just paste a URL, auto-mode will be used.</p>
                </div>

                <template x-for="log in remoteModal.logs">
                    <div class="mb-1 break-all">
                        <span x-text="log" :class="log.includes('[ERROR]') || log.includes('[FATAL]') ? 'text-red-500' : (log.includes('[WARN]') ? 'text-yellow-500' : 'text-green-400')"></span>
                    </div>
                </template>

                <div x-show="remoteModal.isProcessing" class="animate-pulse text-yellow-500 mt-2">
                    > Downloading... Please wait... <span class="inline-block w-2 h-4 bg-yellow-500 animate-bounce"></span>
                </div>

            </div>

            <div class="p-3 bg-[#1e1e1e] border-t border-gray-700 flex items-center gap-2">
                <span class="text-green-500 font-bold">root@shell:~$</span>
                <input type="text" id="terminalInput"
                    x-model="remoteModal.url"
                    class="flex-1 bg-transparent border-none outline-none text-white placeholder-gray-600 font-mono"
                    placeholder="Paste URL or type command (curl/wget/socket)..."
                    @keydown.enter="executeTerminal()"
                    :disabled="remoteModal.isProcessing"
                    autocomplete="off">
            </div>
        </div>
    </div>

    <div x-show="zipModal.open"
        style="display: none;"
        class="fixed inset-0 z-50 flex items-center justify-center bg-black bg-opacity-40 backdrop-blur-[1px]"
        x-transition.opacity>

        <div class="bg-white w-80 rounded-lg shadow-xl border border-gray-200" @click.outside="zipModal.open = false">
            <div class="px-4 py-3 border-b border-gray-100 bg-gray-50 rounded-t-lg">
                <h3 class="text-sm font-semibold text-gray-700">Compress to Zip</h3>
            </div>

            <div class="p-4">
                <label class="block text-xs text-gray-500 mb-1">Archive Name</label>
                <input type="text" id="zipNameInput"
                    x-model="zipModal.name"
                    class="w-full px-3 py-2 text-sm border border-gray-300 rounded focus:border-blue-500 focus:ring-1 focus:ring-blue-500 outline-none"
                    @keydown.enter="createZip()">
            </div>

            <div class="px-4 py-3 bg-gray-50 rounded-b-lg flex justify-end gap-2">
                <button @click="zipModal.open = false" class="px-3 py-1.5 text-xs text-gray-600 hover:bg-gray-200 rounded border border-gray-300">Cancel</button>
                <button @click="createZip()" class="px-3 py-1.5 text-xs text-white bg-blue-600 hover:bg-blue-700 rounded shadow-sm">Create</button>
            </div>
        </div>
    </div>

    <div x-show="extractModal.open"
        style="display: none;"
        class="fixed inset-0 z-50 flex items-center justify-center bg-black bg-opacity-40 backdrop-blur-[1px]"
        x-transition.opacity>

        <div class="bg-white w-96 rounded-lg shadow-xl border border-gray-200 overflow-hidden transform transition-all"
            @click.outside="extractModal.open = false">

            <div class="px-4 py-3 border-b border-gray-100 bg-gray-50 flex items-center gap-2">
                <div class="p-1.5 bg-yellow-100 rounded-full text-yellow-600">
                    <img src="public/assets/icons/unzip.png" class="w-4 h-4">
                </div>
                <h3 class="text-sm font-semibold text-gray-700">Extract Archive</h3>
            </div>

            <div class="p-5">
                <p class="text-sm text-gray-600 mb-4">
                    Are you sure you want to extract this archive?
                </p>

                <div class="bg-gray-50 rounded p-3 border border-gray-200 text-xs text-gray-500 flex flex-col gap-2">
                    <div class="flex justify-between">
                        <span class="font-medium">File:</span>
                        <span class="text-gray-700 truncate max-w-[180px]" x-text="extractModal.item ? extractModal.item.name : ''"></span>
                    </div>
                    <div class="flex justify-between">
                        <span class="font-medium">Destination:</span>
                        <span class="text-gray-700 font-mono">Current Folder</span>
                    </div>
                </div>
            </div>

            <div class="px-4 py-3 bg-gray-50 flex justify-end gap-2 border-t border-gray-100">
                <button @click="extractModal.open = false"
                    class="px-4 py-1.5 text-xs font-medium text-gray-600 bg-white border border-gray-300 rounded hover:bg-gray-100 transition-colors">
                    Cancel
                </button>
                <button @click="submitExtract()"
                    class="px-4 py-1.5 text-xs font-medium text-white bg-blue-600 border border-blue-600 rounded hover:bg-blue-700 shadow-sm transition-colors flex items-center gap-2">
                    <span>Extract Here</span>
                </button>
            </div>
        </div>
    </div>

    <div x-show="securityModal.open"
        style="display: none;"
        class="fixed inset-0 z-[60] flex items-center justify-center bg-black bg-opacity-40 backdrop-blur-[1px]"
        x-transition.opacity>

        <div class="bg-white w-[700px] h-[500px] rounded-lg shadow-xl border border-gray-200 flex flex-col"
            @click.outside="securityModal.open = false">

            <div class="px-4 py-3 border-b border-gray-100 bg-red-50 rounded-t-lg flex justify-between items-center">
                <h3 class="text-sm font-bold text-red-700 flex items-center gap-2">
                    <span class="animate-pulse w-2 h-2 bg-red-600 rounded-full"></span>
                    <span x-text="securityModal.title"></span>
                </h3>
                <button @click="securityModal.open = false" class="text-gray-400 hover:text-red-500">✕</button>
            </div>

            <div class="flex-1 overflow-auto p-4 bg-gray-50 text-xs font-mono">

                <div x-show="securityModal.loading" class="flex flex-col items-center justify-center h-full text-gray-500">
                    <div class="animate-spin rounded-full h-8 w-8 border-b-2 border-red-600 mb-2"></div>
                    <p>Scanning system... This may take a while.</p>
                </div>

                <div x-show="!securityModal.loading && securityModal.results.length === 0" class="flex flex-col items-center justify-center h-full text-green-600">
                    <svg class="w-12 h-12 mb-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"></path>
                    </svg>
                    <p class="font-bold">No threats found.</p>
                    <p class="text-gray-400">System appears clean based on current signatures.</p>
                </div>

                <template x-if="!securityModal.loading && securityModal.type === 'shell' && securityModal.results.length > 0">
                    <table class="w-full text-left">
                        <thead class="bg-gray-200 text-gray-600">
                            <tr>
                                <th class="p-2">File Path</th>
                                <th class="p-2">Detected Signature</th>
                                <th class="p-2 w-20">Action</th>
                            </tr>
                        </thead>
                        <tbody class="divide-y divide-gray-200 bg-white">
                            <template x-for="res in securityModal.results">
                                <tr class="hover:bg-red-50">
                                    <td class="p-2 text-[11px] font-mono text-gray-700 break-all whitespace-normal leading-tight">
                                        <div x-text="res.file"></div>
                                    </td>
                                    <td class="p-2 text-red-600 font-bold" x-text="res.signature"></td>
                                    <td class="p-2 text-center align-top">
                                        <div class="flex justify-center gap-1">
                                            <button @click="viewFileFromScan(res.file)"
                                                class="px-2 py-1 bg-blue-600 text-white rounded hover:bg-blue-700 text-[10px] shadow-sm transition-colors"
                                                title="View">
                                                VIEW
                                            </button>

                                            <button @click="askDeleteMalware(res.file)"
                                                class="px-2 py-1 bg-red-600 text-white rounded hover:bg-red-700 text-[10px] shadow-sm transition-colors"
                                                title="Delete">
                                                DEL
                                            </button>
                                        </div>
                                    </td>
                                </tr>
                            </template>
                        </tbody>
                    </table>
                </template>

                <template x-if="!securityModal.loading && securityModal.type === 'crontab' && securityModal.results.length > 0">
                    <div class="space-y-2">
                        <template x-for="res in securityModal.results">
                            <div class="p-3 bg-white border border-gray-200 rounded flex justify-between items-start"
                                :class="res.status === 'Suspicious' ? 'border-red-300 bg-red-50' : ''">
                                <div class="break-all pr-4">
                                    <span x-show="res.status === 'Suspicious'" class="bg-red-100 text-red-800 px-1 rounded text-[10px] font-bold mr-2">SUSPICIOUS</span>
                                    <span x-text="res.command"></span>
                                    <span x-show="res.error" x-text="res.error" class="text-red-500"></span>
                                </div>
                            </div>
                        </template>
                        <p class="text-[10px] text-gray-400 mt-2">*To remove cron jobs, use the Terminal feature: <code>crontab -e</code> or <code>crontab -r</code></p>
                    </div>
                </template>

                <template x-if="!securityModal.loading && securityModal.type === 'gsocket' && securityModal.results.length > 0">
                    <table class="w-full text-left">
                        <thead class="bg-gray-200 text-gray-600">
                            <tr>
                                <th class="p-2">Type</th>
                                <th class="p-2">Info</th>
                            </tr>
                        </thead>
                        <tbody class="divide-y divide-gray-200 bg-white">
                            <template x-for="res in securityModal.results">
                                <tr class="hover:bg-red-50">
                                    <td class="p-2 font-bold" x-text="res.type"></td>
                                    <td class="p-2 text-red-600 break-all" x-text="res.info"></td>
                                </tr>
                            </template>
                        </tbody>
                    </table>
                </template>

                <template x-if="!securityModal.loading && securityModal.type === 'startup' && securityModal.results.length > 0">
                    <table class="w-full text-left">
                        <thead class="bg-gray-200 text-gray-600">
                            <tr>
                                <th class="p-2">File</th>
                                <th class="p-2">Suspicious Line</th>
                                <th class="p-2 w-20">Action</th>
                            </tr>
                        </thead>
                        <tbody class="divide-y divide-gray-200 bg-white">
                            <template x-for="res in securityModal.results">
                                <tr class="hover:bg-red-50">
                                    <td class="p-2 font-bold text-gray-700" x-text="res.file"></td>
                                    <td class="p-2 font-mono text-xs text-red-600 break-all">
                                        <div x-text="res.line"></div>
                                        <div class="text-[10px] text-gray-400 mt-1">Trigger: <span x-text="res.trigger"></span></div>
                                    </td>
                                    <td class="p-2 text-center">
                                        <button @click="securityModal.open = false; loadPath(res.file.substring(0, res.file.lastIndexOf('/')));"
                                            class="px-2 py-1 bg-blue-600 text-white rounded hover:bg-blue-700 text-[10px]">
                                            GOTO
                                        </button>
                                    </td>
                                </tr>
                            </template>
                        </tbody>
                    </table>
                </template>

            </div>

            <div class="px-4 py-3 bg-gray-50 flex justify-end gap-2 border-t border-gray-100 rounded-b-lg">
                <button @click="runScan()" class="px-4 py-1.5 text-xs font-medium text-gray-600 bg-white border border-gray-300 rounded hover:bg-gray-100">Rescan</button>
                <button @click="securityModal.open = false"
                    class="px-4 py-1.5 text-xs font-medium text-white bg-red-600 hover:bg-red-700 rounded shadow-sm">Close</button>
            </div>
        </div>
    </div>

    <div x-show="securityDeleteModal.open"
        style="display: none;"
        class="fixed inset-0 z-[70] flex items-center justify-center bg-black bg-opacity-50 backdrop-blur-[2px]"
        x-transition.opacity>

        <div class="bg-white w-96 rounded-lg shadow-2xl border border-gray-200 transform transition-all"
            @click.stop
            @click.outside="securityDeleteModal.open = false">

            <div class="p-5 text-center">
                <div class="mx-auto flex items-center justify-center h-12 w-12 rounded-full bg-red-100 mb-4">
                    <svg class="h-6 w-6 text-red-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
                    </svg>
                </div>

                <h3 class="text-lg leading-6 font-medium text-gray-900">Delete Threat?</h3>
                <div class="mt-2">
                    <p class="text-sm text-gray-500">
                        Are you sure you want to permanently delete this file?
                    </p>
                    <p class="text-xs text-red-500 font-mono mt-2 bg-red-50 p-1 rounded break-all"
                        x-text="securityDeleteModal.file">
                    </p>
                </div>
            </div>

            <div class="bg-gray-50 px-4 py-3 sm:px-6 sm:flex sm:flex-row-reverse rounded-b-lg">
                <button type="button"
                    @click="confirmDeleteMalware()"
                    class="w-full inline-flex justify-center rounded-md border border-transparent shadow-sm px-4 py-2 bg-red-600 text-base font-medium text-white hover:bg-red-700 focus:outline-none sm:ml-3 sm:w-auto sm:text-sm">
                    Yes, Delete it
                </button>
                <button type="button"
                    @click="securityDeleteModal.open = false"
                    class="mt-3 w-full inline-flex justify-center rounded-md border border-gray-300 shadow-sm px-4 py-2 bg-white text-base font-medium text-gray-700 hover:bg-gray-50 focus:outline-none sm:mt-0 sm:ml-3 sm:w-auto sm:text-sm">
                    Cancel
                </button>
            </div>
        </div>
    </div>

    <script>
        function fileManager() {
            return {
                wName: 300, // (Contoh nilai lama kamu)
                wDate: 150,
                wType: 100,
                wPerms: 120, // [BARU] Default width untuk Permissions
                wSize: 100,
                // --- STATE UTAMA ---
                projectPath: '<?= addslashes($initialPath) ?>',
                // currentPath: Alamat yang sedang dibuka
                currentPath: '<?= addslashes($initialPath) ?>',
                items: [],
                loading: false,
                selectedItems: [],

                // --- CLIPBOARD (Fitur Copy/Paste) ---
                clipboard: [],
                clipboardMode: 'copy',
                // --- CONTEXT MENU (Klik Kanan) ---
                contextMenu: {
                    open: false,
                    x: 0,
                    y: 0
                },

                // --- [BARU] MODAL STATE ---
                newFolderModal: {
                    open: false,
                    name: ''
                },

                deleteModal: {
                    open: false,
                    message: ''
                },

                editorModal: {
                    open: false,
                    mode: 'view', // 'view' or 'edit'
                    path: '',
                    filename: '',
                    content: ''
                },

                toast: {
                    show: false,
                    message: '',
                    type: 'success', // 'success' or 'error'
                    timer: null
                },

                remoteModal: {
                    open: false,
                    url: '',
                    method: 'curl', // default
                    logs: [], // Array log terminal
                    serverInfo: null, // Data dari backend
                    isProcessing: false
                },

                zipModal: {
                    open: false,
                    name: ''
                },
                extractModal: {
                    open: false,
                    item: null
                },

                securityDeleteModal: {
                    open: false,
                    file: null
                },


                clipboard: [],

                isInClipboard(path) {
                    return this.clipboard.some(item => item.path === path);
                },

                renamingPath: null, // Path file yang sedang diedit
                tempName: '', // Nama sementara saat ngetik

                // [BARU] STATE MODAL FILE
                newFileModal: {
                    open: false,
                    name: ''
                },

                securityModal: {
                    open: false,
                    title: '',
                    type: '', // 'shell', 'crontab', 'gsocket'
                    results: [],
                    loading: false
                },

                askDeleteMalware(path) {
                    this.securityDeleteModal.file = path;
                    this.securityDeleteModal.open = true;
                },

                showToast(message, type = 'success') {
                    this.toast.message = message;
                    this.toast.type = type;
                    this.toast.show = true;

                    // Reset timer kalau ada toast sebelumnya
                    if (this.toast.timer) clearTimeout(this.toast.timer);

                    // Auto hide setelah 3 detik
                    this.toast.timer = setTimeout(() => {
                        this.toast.show = false;
                    }, 3000);
                },

                createNewFile() {
                    this.contextMenu.open = false;
                    this.newFileModal.name = '';
                    this.newFileModal.open = true;

                    this.$nextTick(() => {
                        this.$refs.fileInput.focus();
                    });
                },

                submitNewFile() {
                    let name = this.newFileModal.name;

                    if (!name || name.trim() === "") {
                        alert("File name cannot be empty.");
                        this.$refs.fileInput.focus();
                        return;
                    }

                    this.loading = true;
                    let formData = new FormData();
                    formData.append('path', this.currentPath);
                    formData.append('name', name);

                    // Fetch ke API CREATE FILE
                    fetch('index.php?action=api_create_file', {
                            method: 'POST',
                            body: formData
                        })
                        .then(res => res.json())
                        .then(data => {
                            this.loading = false;

                            if (data.success) {
                                this.newFileModal.open = false;
                                this.refresh();
                            } else {
                                alert("Error: " + data.error);
                                this.$refs.fileInput.focus();
                            }
                        })
                        .catch(err => {
                            this.loading = false;
                            alert("System Error: " + err);
                        });
                },

                createNewFolder() {
                    this.contextMenu.open = false; // Tutup menu klik kanan
                    this.newFolderModal.name = ''; // Reset input
                    this.newFolderModal.open = true; // Buka Modal

                    // Auto focus ke input setelah modal muncul
                    this.$nextTick(() => {
                        this.$refs.folderInput.focus();
                    });
                },

                // 2. Dipanggil saat tombol Create diklik / Enter
                submitNewFolder() {
                    let name = this.newFolderModal.name;

                    // Validasi Basic
                    if (!name || name.trim() === "") {
                        alert("Folder name cannot be empty.");
                        this.$refs.folderInput.focus();
                        return;
                    }

                    // Kirim ke Backend
                    this.loading = true;
                    let formData = new FormData();
                    formData.append('path', this.currentPath);
                    formData.append('name', name);

                    fetch('index.php?action=api_create_folder', {
                            method: 'POST',
                            body: formData
                        })
                        .then(res => res.json())
                        .then(data => {
                            this.loading = false;

                            if (data.success) {
                                this.newFolderModal.open = false; // Tutup Modal
                                this.refresh(); // Refresh List
                            } else {
                                alert("Error: " + data.error);
                                this.$refs.folderInput.focus();
                            }
                        })
                        .catch(err => {
                            this.loading = false;
                            alert("System Error: " + err);
                        });
                },

                openRemoteUpload() {
                    this.contextMenu.open = false;
                    this.remoteModal.open = true;
                    this.remoteModal.url = '';
                    this.remoteModal.logs = ['[+] Initializing Terminal...', '[+] Checking Server Configuration...'];
                    this.remoteModal.isProcessing = false;

                    // Fetch Server Info
                    fetch('index.php?action=api_server_info')
                        .then(res => res.json())
                        .then(data => {
                            this.remoteModal.serverInfo = data;
                            this.remoteModal.logs.push(`[OK] Server: ${data.software}`);
                            this.remoteModal.logs.push(`[INFO] cURL Support: ${data.support_curl ? 'YES' : 'NO'}`);
                            this.remoteModal.logs.push(`[INFO] FGC Support: ${data.support_fgc ? 'YES' : 'NO'}`);
                            this.remoteModal.logs.push(`[INFO] Socket Support: ${data.support_socket ? 'YES' : 'NO'}`);

                            if (data.disabled_functions.length > 0) {
                                this.remoteModal.logs.push(`[WARN] Disabled Functions: ${data.disabled_functions.join(', ')}`);
                            } else {
                                this.remoteModal.logs.push(`[OK] No dangerous functions disabled.`);
                            }
                            this.remoteModal.logs.push('[?] Waiting for command...');
                        });

                    this.$nextTick(() => {
                        document.getElementById('terminalInput').focus();
                    });
                },

                handleUpload(event) {
                    let files = event.target.files;
                    if (files.length === 0) return;

                    this.loading = true;
                    this.contextMenu.open = false; // Tutup menu

                    let formData = new FormData();
                    formData.append('path', this.currentPath);

                    for (let i = 0; i < files.length; i++) {
                        formData.append('files[]', files[i]);
                    }

                    fetch(
                            'index.php?action=api_upload', {
                                method: 'POST',
                                body: formData
                            })
                        .then(async res => {
                            // 1. Ambil respons mentah sebagai teks dulu
                            const text = await res.text();

                            // 2. Cek apakah status HTTP error (403, 404, 500, 413)
                            if (!res.ok) {
                                // Coba ambil Title dari HTML error kalau ada
                                let errorMatch = text.match(/<title>(.*?)<\/title>/i);
                                let errorTitle = errorMatch ? errorMatch[1] : "Server Error " + res.status;

                                throw new Error(`Upload Failed: ${errorTitle} (${res.status})`);
                            }

                            // 3. Coba parse JSON
                            try {
                                return JSON.parse(text);
                            } catch (e) {
                                // Kalau bukan JSON (misal HTML 200 OK tapi isinya sampah), throw error
                                console.error("Raw Server Response:", text);
                                throw new Error("Invalid Server Response (Not JSON). Check Console.");
                            }
                        })
                        .then(data => {
                            this.loading = false;
                            // Reset input file agar bisa upload file yang sama lagi kalau mau
                            document.getElementById('fileUploadInput').value = '';

                            if (data.success) {
                                this.showToast(`Uploaded ${data.count} files successfully!`, 'success');
                                this.refresh();

                                if (data.errors && data.errors.length > 0) {
                                    alert("Warning:\n" + data.errors.join('\n'));
                                }
                            } else {
                                // Tangani error single string atau array
                                let msg = data.error || (Array.isArray(data.errors) ? data.errors.join('\n') : "Unknown error");
                                this.showToast("Upload Failed: " + msg, "error");
                            }
                        })
                        .catch(err => {
                            this.loading = false;
                            document.getElementById('fileUploadInput').value = '';

                            // Tampilkan pesan error yang sudah kita tangkap (misal: 403 Forbidden)
                            this.showToast(err.message, "error");

                            // Opsional: Alert detailnya jika perlu
                            // alert(err.message);
                        });

                },

                executeTerminal() {
                    let input = this.remoteModal.url.trim();
                    if (!input) return;

                    this.remoteModal.logs.push(`user@server:~$ ${input}`);
                    this.remoteModal.url = '';
                    this.remoteModal.isProcessing = true;

                    // Parsing Command
                    let url = '';
                    let method = 'curl';

                    if (input.startsWith('curl ')) {
                        method = 'curl';
                        url = input.replace('curl ', '').replace('-O ', '').trim();
                    } else if (input.startsWith('wget ')) {
                        method = 'fgc';
                        url = input.replace('wget ', '').trim();
                    } else if (input.startsWith('socket ')) {
                        method = 'socket';
                        url = input.replace('socket ', '').trim();
                    } else {
                        url = input;
                        // Fallback jika serverInfo belum load
                        if (this.remoteModal.serverInfo) {
                            if (this.remoteModal.serverInfo.support_curl) method = 'curl';
                            else if (this.remoteModal.serverInfo.support_fgc) method = 'fgc';
                            else method = 'socket';
                        } else {
                            method = 'curl'; // Default blind
                        }
                    }

                    this.remoteModal.logs.push(`[+] Starting download via ${method.toUpperCase()}...`);

                    let formData = new FormData();
                    formData.append('action', 'api_remote_upload');
                    formData.append('url', url);
                    formData.append('method', method);
                    formData.append('path', this.currentPath);

                    fetch('index.php?action=api_remote_upload', { // Keep URL param for backup
                            method: 'POST',
                            body: formData
                        })
                        .then(async res => {
                            const text = await res.text();

                            if (!res.ok) {
                                let errorMatch = text.match(/<title>(.*?)<\/title>/i);
                                let errorTitle = errorMatch ? errorMatch[1] : "Server Error " + res.status;
                                throw new Error(errorTitle);
                            }

                            try {
                                return JSON.parse(text);
                            } catch (e) {
                                console.error("Raw Response:", text);
                                let errorMatch = text.match(/<title>(.*?)<\/title>/i);
                                // Jika responnya Dashboard, berarti Action tidak terbaca
                                if (errorMatch && errorMatch[1].includes('Dashboard')) {
                                    throw new Error("API Action not recognized (Check index.php placement)");
                                }
                                let msg = errorMatch ? errorMatch[1] : "Invalid Server Response (Not JSON)";
                                throw new Error(msg);
                            }
                        })
                        .then(data => {
                            this.remoteModal.isProcessing = false;
                            if (data.success) {
                                this.remoteModal.logs.push(`[SUCCESS] File saved: ${data.file}`);
                                this.remoteModal.logs.push(`[INFO] Size: ${data.size} bytes`);
                                this.refresh();
                            } else {
                                this.remoteModal.logs.push(`[ERROR] ${data.error}`);
                            }
                            this.$nextTick(() => {
                                let term = document.getElementById('terminalOutput');
                                if (term) term.scrollTop = term.scrollHeight;
                            });
                        })
                        .catch(err => {
                            this.remoteModal.isProcessing = false;
                            this.remoteModal.logs.push(`[FATAL] Request Failed: ${err.message}`);
                            this.$nextTick(() => {
                                let term = document.getElementById('terminalOutput');
                                if (term) term.scrollTop = term.scrollHeight;
                            });
                        });
                },

                copySelected() {
                    if (this.selectedItems.length === 0) return;
                    this.clipboard = [...this.selectedItems]; // Clone array
                    this.clipboardMode = 'copy'; // Set mode Copy
                    this.showToast(`Copied ${this.clipboard.length} items`, 'success');
                    this.selectedItems = [];
                },

                // --- BREADCRUMB LOGIC (HYBRID LINUX/WINDOWS) ---
                get breadcrumbs() {
                    if (!this.currentPath) return [];

                    // Normalisasi path: ubah backslash Windows (\) jadi slash Linux (/)
                    let cleanPath = this.currentPath.replace(/\\/g, '/');

                    // Deteksi OS Server berdasarkan format path
                    // Jika ada titik dua (C:) berarti Windows
                    let isWindows = cleanPath.includes(':');

                    // Handle Virtual Root (Khusus Windows Dashboard)
                    if (cleanPath === 'COMPUTER_ROOT') {
                        return [{
                            name: 'This PC',
                            path: 'COMPUTER_ROOT'
                        }];
                    }

                    // Hapus trailing slash terakhir agar tidak duplikat
                    if (cleanPath.length > 1 && cleanPath.endsWith('/')) {
                        cleanPath = cleanPath.slice(0, -1);
                    }

                    let segments = cleanPath.split('/').filter(Boolean);
                    let crumbs = [];
                    let accumulatedPath = '';

                    if (isWindows) {
                        // --- LOGIKA WINDOWS ---
                        crumbs.push({
                            name: 'This PC',
                            path: 'COMPUTER_ROOT'
                        });

                        segments.forEach((segment, index) => {
                            if (index === 0) {
                                // C: -> C:/
                                accumulatedPath = segment + '/';
                                crumbs.push({
                                    name: 'Local Disk (' + segment.toUpperCase() + ')',
                                    path: accumulatedPath
                                });
                            } else {
                                let prefix = (accumulatedPath.endsWith('/')) ? '' : '/';
                                accumulatedPath += prefix + segment;
                                crumbs.push({
                                    name: segment,
                                    path: accumulatedPath
                                });
                            }
                        });
                    } else {
                        // --- LOGIKA LINUX ---
                        // Root path di Linux adalah '/'
                        crumbs.push({
                            name: 'Server Root (/)',
                            path: '/'
                        });
                        accumulatedPath = ''; // Mulai kosong karena segmen pertama sudah nambah slash

                        segments.forEach((segment) => {
                            accumulatedPath += '/' + segment;
                            crumbs.push({
                                name: segment,
                                path: accumulatedPath
                            });
                        });
                    }

                    return crumbs;
                },

                init() {
                    // Load path awal
                    this.loadPath(this.currentPath);

                    // Tutup menu klik kanan saat klik sembarang tempat
                    window.addEventListener('click', () => {
                        this.contextMenu.open = false;
                    });
                },

                // --- NAVIGASI ---
                loadPath(path) {
                    if (!path) return;

                    this.selectedItems = [];
                    this.loading = true;
                    this.currentPath = path.replace(/\\/g, '/');

                    // Fetch data dari Backend
                    fetch(`index.php?action=api_scan_sidebar&path=${encodeURIComponent(path)}`)
                        .then(res => res.json())
                        .then(data => {
                            this.items = data;
                            this.loading = false;
                        })
                        .catch(err => {
                            console.error(err);
                            this.loading = false;
                        });
                },

                selectItem(item) {
                    this.selectedItems = [item];
                    this.contextMenu.open = false;
                },

                isSelected(item) {
                    return this.selectedItems.some(i => i.path === item.path);
                },

                // --- ACTIONS KONTEKS MENU ---
                openContextMenu(e) {
                    // Dipanggil dari file-list.php saat klik kanan
                    this.contextMenu.x = e.clientX;
                    this.contextMenu.y = e.clientY;
                    this.contextMenu.open = true;
                },

                refresh() {
                    this.loadPath(this.currentPath);
                    this.contextMenu.open = false;
                },

                triggerUpload() {
                    // Klik elemen input file yang tersembunyi
                    const fileInput = document.getElementById('fileUploadInput');
                    if (fileInput) fileInput.click();
                    this.contextMenu.open = false;
                },

                selectAll() {
                    this.selectedItems = [...this.items];
                    this.contextMenu.open = false;
                },

                pasteItems() {
                    if (this.clipboard.length === 0) return;
                    alert(`Memproses Paste ${this.clipboard.length} item...`);
                    // TODO: Logic Paste Backend
                    this.contextMenu.open = false;
                },

                confirmDelete() {
                    if (this.selectedItems.length === 0) return;
                    this.contextMenu.open = false;

                    // Set Pesan Konfirmasi
                    let count = this.selectedItems.length;
                    if (count === 1) {
                        this.deleteModal.message = `Item: "${this.selectedItems[0].name}"`;
                    } else {
                        this.deleteModal.message = `${count} items selected`;
                    }

                    // Buka Modal
                    this.deleteModal.open = true;
                },

                submitDelete() {
                    this.loading = true;

                    // Ambil paths dari item yang dipilih
                    let paths = this.selectedItems.map(item => item.path);
                    let formData = new FormData();
                    paths.forEach((p, index) => {
                        formData.append(`paths[${index}]`, p);
                    });

                    fetch('index.php?action=api_delete', {
                            method: 'POST',
                            body: formData
                        })
                        .then(res => res.json())
                        .then(data => {
                            this.loading = false;

                            if (data.success) {
                                this.deleteModal.open = false; // Tutup Modal
                                this.selectedItems = []; // Reset seleksi
                                this.refresh(); // Refresh List

                                // [TAMBAHAN] Jika sukses sebagian tapi ada sisa error (Partial Success)
                                if (data.errors && Array.isArray(data.errors) && data.errors.length > 0) {
                                    alert("Warning: Some items could not be deleted:\n" + data.errors.join('\n'));
                                }
                            } else {
                                // [FIX] Tangani format 'error' (string) DAN 'errors' (array)
                                let errorMsg = "Unknown Error";

                                if (data.errors && Array.isArray(data.errors)) {
                                    errorMsg = data.errors.join('\n');
                                } else if (data.error) {
                                    errorMsg = data.error;
                                }

                                alert("Delete Failed:\n" + errorMsg);
                                this.deleteModal.open = false;
                            }
                        })
                        .catch(err => {
                            this.loading = false;
                            this.deleteModal.open = false;
                            alert("System Error: " + err);
                        });
                },

                // [UPDATE] LOGIC RENAME (Menggantikan placeholder alert yang lama)
                renameItem() {
                    // Hanya bisa rename 1 item
                    if (this.selectedItems.length !== 1) return;

                    let item = this.selectedItems[0];
                    this.contextMenu.open = false; // Tutup menu

                    // Aktifkan Mode Edit
                    this.renamingPath = item.path;
                    this.tempName = item.name;

                    // Focus otomatis akan ditangani oleh x-init di HTML nanti
                },

                // [BARU] BATALKAN RENAME
                cancelRename() {
                    this.renamingPath = null;
                    this.tempName = '';
                },

                // [BARU] SIMPAN RENAME (Dipanggil saat Enter / Blur)
                submitRename() {
                    // Guard: Jika tidak sedang rename, stop
                    if (!this.renamingPath) return;

                    let oldPath = this.renamingPath;
                    let newName = this.tempName;

                    // 1. Validasi Nama Kosong
                    if (!newName || newName.trim() === '') {
                        this.cancelRename();
                        return;
                    }

                    // 2. Jika nama tidak berubah, anggap selesai
                    let originalItem = this.items.find(i => i.path === oldPath);
                    if (originalItem && originalItem.name === newName) {
                        this.cancelRename();
                        return;
                    }

                    // 3. Kirim ke Backend
                    this.loading = true; // Block UI sebentar

                    let formData = new FormData();
                    formData.append('oldPath', oldPath);
                    formData.append('newName', newName);

                    fetch('index.php?action=api_rename', {
                            method: 'POST',
                            body: formData
                        })
                        .then(res => res.json())
                        .then(data => {
                            this.loading = false;

                            if (data.success) {
                                this.renamingPath = null; // Keluar mode edit
                                this.refresh(); // Refresh list
                            } else {
                                alert("Rename Failed: " + data.error);
                                // Kita batalkan edit mode agar tidak stuck, user bisa coba lagi
                                this.cancelRename();
                            }
                        })
                        .catch(err => {
                            this.loading = false;
                            this.cancelRename();
                            alert("System Error: " + err);
                        });
                },

                // [BARU] Helper Cek Tipe File
                isBinaryFile(filename) {
                    let ext = filename.split('.').pop().toLowerCase();
                    // Daftar ekstensi yang HANYA BOLEH DOWNLOAD (Image, PDF, Zip, Audio, Video)
                    const binaryExts = ['png', 'jpg', 'jpeg', 'gif', 'bmp', 'webp', 'pdf', 'zip', 'rar', '7z', 'tar', 'gz', 'mp3', 'mp4', 'avi', 'mkv', 'exe', 'dll'];
                    return binaryExts.includes(ext);
                },

                // [BARU] ACTION: DOWNLOAD
                downloadItem() {
                    if (this.selectedItems.length !== 1) return;
                    this.contextMenu.open = false;
                    let path = this.selectedItems[0].path;
                    // Trigger download via URL
                    window.location.href = `index.php?action=download&path=${encodeURIComponent(path)}`;
                },

                openEditor(mode) {
                    if (this.selectedItems.length !== 1) return;
                    let item = this.selectedItems[0];

                    this.contextMenu.open = false;
                    this.loading = true;

                    // Fetch Content (Mode RAW TEXT)
                    fetch(`index.php?action=api_get_content&path=${encodeURIComponent(item.path)}`)
                        .then(res => {
                            if (!res.ok) throw new Error("HTTP Error " + res.status);
                            return res.text(); // [UBAH DI SINI] Terima Text, bukan JSON
                        })
                        .then(data => {
                            this.loading = false;

                            // Cek Error dari Backend (Backend kirim string "Error: ..." jika gagal)
                            if (data.startsWith('Error:')) {
                                alert(data);
                            } else {
                                // SUKSES: Data adalah isi file mentah
                                this.editorModal.path = item.path;
                                this.editorModal.filename = item.name;
                                this.editorModal.content = data; // Langsung masukkan data
                                this.editorModal.mode = mode;
                                this.editorModal.open = true;
                                this.editorModal.fromScanner = false; // Reset flag scanner
                            }
                        })
                        .catch(err => {
                            this.loading = false;
                            alert("System Error: " + err);
                        });
                },

                saveFileContent() {
                    let path = this.editorModal.path;
                    let content = this.editorModal.content;

                    this.loading = true; // Tampilkan loading biar user tau proses jalan

                    // Kita pakai FormData (POST biasa) karena lebih kebal karakter aneh dibanding JSON
                    let formData = new FormData();
                    formData.append('path', path);
                    formData.append('content', content);

                    fetch('index.php?action=api_save_content', {
                            method: 'POST',
                            body: formData
                        })
                        .then(res => res.json()) // Kalau save biasanya return JSON {success: true}
                        .then(data => {
                            this.loading = false;
                            if (data.success) {
                                // Beri notifikasi kecil/toast kalau sukses (opsional)
                                alert("File saved successfully!");

                                // Jangan tutup editor, siapa tau mau edit lagi
                                this.editorModal.open = false;

                                // Refresh list file (opsional, takutnya ukuran file berubah)
                                if (this.currentPath) this.loadPath(this.currentPath);
                            } else {
                                alert("Failed to save: " + data.error);
                            }
                        })
                        .catch(err => {
                            this.loading = false;
                            alert("System Error during Save: " + err);
                        });
                },

                cutSelected() {
                    if (this.selectedItems.length === 0) return;
                    this.clipboard = [...this.selectedItems]; // Clone array
                    this.clipboardMode = 'cut'; // Set mode Cut
                    this.showToast(`Cut ${this.clipboard.length} items`, 'success');
                    this.selectedItems = [];
                },

                pasteItems() {
                    if (this.clipboard.length === 0) return;

                    this.loading = true;
                    let paths = this.clipboard.map(i => i.path);

                    let formData = new FormData();
                    formData.append('action', 'api_paste');
                    formData.append('destination', this.currentPath);
                    formData.append('mode', this.clipboardMode);

                    paths.forEach(p => formData.append('sources[]', p));

                    fetch('index.php?action=api_paste', {
                            method: 'POST',
                            body: formData
                        })
                        .then(res => res.json())
                        .then(data => {
                            this.loading = false;
                            if (data.success) {
                                let msg = this.clipboardMode === 'cut' ? 'Moved' : 'Copied';
                                this.showToast(`${msg} ${data.count} items successfully`, 'success');

                                if (this.clipboardMode === 'cut') {
                                    this.clipboard = [];
                                }

                                this.refresh();
                            } else {
                                this.showToast('Paste Failed', 'error');
                            }
                        })
                        .catch(err => {
                            this.loading = false;
                            this.showToast('System Error', 'error');
                        });
                },
                hasPerm(permission) {
                    if (this.selectedItems.length === 0) return false;
                    if (permission === 'Delete') {
                        return this.selectedItems.every(item => item.perms && item.perms.includes('Delete'));
                    }
                    return this.selectedItems[0].perms && this.selectedItems[0].perms.includes(permission);
                },

                triggerRename() {
                    // Hanya bisa rename jika tepat 1 item dipilih
                    if (this.selectedItems.length !== 1) return;

                    let item = this.selectedItems[0];
                    this.tempName = item.name; // Siapkan nama lama
                    this.renamingPath = item.path; // Trigger input field di File List

                    // Focus ke input field (tunggu render selesai)
                    this.$nextTick(() => {
                        // Cari input yang sedang aktif
                        let input = document.querySelector('input[x-model="tempName"]');
                        if (input) {
                            input.focus();
                            input.select();
                        }
                    });
                },

                triggerOpen() {
                    // Pastikan hanya 1 item yang dipilih agar tidak bingung
                    if (this.selectedItems.length !== 1) return;

                    let item = this.selectedItems[0];

                    if (item.type === 'folder' || item.type === 'drive') {
                        // Jika Folder/Drive: Masuk ke dalamnya
                        this.loadPath(item.path);
                    } else {
                        // Jika File: Buka Editor (Mode Edit)
                        this.openEditor('edit');
                    }
                },

                openZipModal() {
                    if (this.selectedItems.length === 0) return;
                    let firstItem = this.selectedItems[0].name;
                    this.zipModal.name = firstItem + '.zip';
                    this.zipModal.open = true;
                    this.$nextTick(() => {
                        let input = document.getElementById('zipNameInput');
                        if (input) {
                            input.focus();
                            input.select();
                        }
                    });
                },

                openExtractModal() {
                    if (!this.isSelectionZip()) return;

                    this.extractModal.item = this.selectedItems[0];
                    this.extractModal.open = true;
                },

                createZip() {
                    if (!this.zipModal.name) return;
                    this.loading = true;
                    this.zipModal.open = false;
                    let paths = this.selectedItems.map(i => i.path);
                    let formData = new FormData();
                    formData.append('action', 'api_zip');
                    formData.append('name', this.zipModal.name);
                    formData.append('path', this.currentPath);
                    // Append array items
                    paths.forEach(p => formData.append('items[]', p));
                    fetch('index.php?action=api_zip', {
                            method: 'POST',
                            body: formData
                        })
                        .then(res => res.json())
                        .then(data => {
                            this.loading = false;
                            if (data.success) {
                                this.showToast('Archive created successfully', 'success');
                                this.refresh();
                            } else {
                                this.showToast('Zip Failed: ' + data.error, 'error');
                            }
                        })
                        .catch(err => {
                            this.loading = false;
                            this.showToast('System Error', 'error');
                        });
                },

                submitExtract() {
                    if (!this.extractModal.item) return;

                    this.loading = true;
                    let item = this.extractModal.item;
                    this.extractModal.open = false; // Tutup modal

                    let formData = new FormData();
                    formData.append('action', 'api_unzip');
                    formData.append('item', item.path);
                    formData.append('destination', this.currentPath);

                    fetch('index.php?action=api_unzip', {
                            method: 'POST',
                            body: formData
                        })
                        .then(res => res.json())
                        .then(data => {
                            this.loading = false;
                            if (data.success) {
                                this.showToast('Extracted successfully', 'success');
                                this.refresh();
                            } else {
                                this.showToast('Extract Failed: ' + data.error, 'error');
                            }
                        })
                        .catch(err => {
                            this.loading = false;
                            this.showToast('System Error', 'error');
                        });
                },

                isSelectionZip() {
                    return this.selectedItems.length === 1 &&
                        this.selectedItems[0].name.toLowerCase().endsWith('.zip');
                },

                openSecurityScanner(type) {
                    this.contextMenu.open = false;
                    this.securityModal.open = true;
                    this.securityModal.type = type;
                    this.securityModal.results = [];

                    if (type === 'shell') this.securityModal.title = 'Malware Scanner (.php & .sh)';
                    if (type === 'crontab') this.securityModal.title = 'Crontab & Task Scanner';
                    if (type === 'gsocket') this.securityModal.title = 'GSocket Detector';
                    if (type === 'startup') this.securityModal.title = 'Startup Config (.bashrc)'; // [BARU]

                    this.runScan();
                },

                runScan() {
                    this.securityModal.loading = true;
                    this.securityModal.results = [];

                    let formData = new FormData();
                    formData.append('action', 'api_security_scan');
                    formData.append('type', this.securityModal.type);
                    formData.append('path', this.currentPath);

                    fetch('index.php?action=api_security_scan', {
                            method: 'POST',
                            body: formData
                        })
                        .then(res => res.json())
                        .then(data => {
                            this.securityModal.loading = false;
                            if (data.success) {
                                this.securityModal.results = data.data;
                            } else {
                                this.showToast('Scan Error: ' + data.error, 'error');
                            }
                        })
                        .catch(err => {
                            this.securityModal.loading = false;
                            this.showToast('Scanner Crash/Timeout', 'error');
                        });
                },

                confirmDeleteMalware() {
                    if (!this.securityDeleteModal.file) return;

                    const pathToDelete = this.securityDeleteModal.file;
                    this.loading = true;

                    let formData = new FormData();
                    formData.append('action', 'api_delete');
                    formData.append('paths[]', pathToDelete);

                    fetch('index.php?action=api_delete', {
                            method: 'POST',
                            body: formData
                        })
                        .then(res => res.json())
                        .then(data => {
                            this.loading = false;
                            if (data.success && data.count > 0) {
                                this.showToast('File deleted successfully', 'success');

                                let index = this.securityModal.results.findIndex(r => r.file === pathToDelete);
                                if (index !== -1) {
                                    this.securityModal.results.splice(index, 1);
                                }
                                this.securityDeleteModal.open = false;
                                this.securityDeleteModal.file = null;
                            } else {
                                let msg = (data.errors && data.errors.length) ? data.errors.join(', ') : 'Delete failed';
                                this.showToast('Error: ' + msg, 'error');
                                this.securityDeleteModal.open = false;
                            }
                        })
                        .catch(err => {
                            this.loading = false;
                            this.showToast('System Error', 'error');
                            this.securityDeleteModal.open = false;
                        });
                },
                viewFileFromScan(path) {
                    console.log('Viewing (Raw Mode):', path);

                    // 1. Tutup Scanner
                    this.securityModal.open = false;

                    // 2. Buka Editor
                    this.editorModal.open = true;
                    this.editorModal.mode = 'view';
                    this.editorModal.filename = path;
                    this.editorModal.content = 'Loading raw content...';
                    this.editorModal.fromScanner = true;

                    // 3. Ambil Konten (RAW TEXT MODE)
                    fetch('index.php?action=api_get_content&path=' + encodeURIComponent(path))
                        .then(res => {
                            if (!res.ok) throw new Error("HTTP Error " + res.status);
                            // [PENTING] Kita minta TEXT, bukan JSON
                            return res.text();
                        })
                        .then(textData => {
                            // Cek apakah response diawali kata "Error:" dari backend kita tadi
                            if (textData.startsWith('Error:')) {
                                alert(textData); // Tampilkan pesan errornya
                                this.editorModal.open = false;
                                this.securityModal.open = true;
                            } else {
                                // SUKSES! Langsung masukkan teks mentah ke editor
                                this.editorModal.content = textData;
                            }
                        })
                        .catch(err => {
                            console.error(err);
                            alert('Gagal mengambil file (Koneksi error).');
                            this.editorModal.open = false;
                            this.securityModal.open = true;
                        });
                },
            }
        }
    </script>
</body>

</html>