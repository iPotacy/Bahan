<!DOCTYPE html>
<html lang="id" class="h-full">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - <?= \App\Core\Config::APP_NAME ?></title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        body { font-family: 'Inter', sans-serif; }
        .fade-in { animation: fadeIn 0.6s cubic-bezier(0.22, 1, 0.36, 1); }
        @keyframes fadeIn { from { opacity: 0; transform: translateY(15px); } to { opacity: 1; transform: translateY(0); } }
    </style>
</head>

<body class="h-full flex items-center justify-center bg-cover bg-center overflow-hidden" 
      style="background-image: url('<?= $loginBanner ?>');">
    
    <div class="absolute inset-0 bg-black/20"></div>

    <div class="w-[390px] rounded-lg shadow-2xl overflow-hidden relative z-10 fade-in flex flex-col">
        
        <div class="h-[120px] bg-gray-900/70 backdrop-blur-sm relative flex flex-col items-center justify-center border-b border-white/10">
            
            <div class="flex items-center gap-1 mb-1 transform scale-95 origin-bottom">
                <span class="text-3xl font-bold text-[#4facfe]">Brother</span>
                <span class="text-3xl font-bold text-[#a18cd1]">Line</span>
                <span class="text-xl text-gray-300 font-medium ml-1 mt-2">Cloud</span>
            </div>
            
            <div class="absolute bottom-3 right-4 text-white/60 text-[10px] font-light tracking-wide">
                —— Cloud Manager
            </div>
        </div>

        <div class="bg-white px-12 pt-5 pb-10">
            <?php if(isset($error)): ?>
                <div class="p-2 bg-red-50 border border-red-100 text-red-500 text-[11px] text-center rounded shadow-sm">
                    <?= $error ?>
                </div>
            <?php endif; ?>

            <form method="POST" action="index.php?action=login" class="space-y-5 mt-7">
                
                <div class="flex h-9 border border-gray-300 rounded overflow-hidden shadow-sm hover:border-blue-400 transition-colors group">
                    <div class="w-10 bg-[#f5f5f5] flex items-center justify-center border-r border-gray-300 group-hover:border-blue-400 group-hover:bg-[#ebebeb] transition-colors">
                        <svg class="w-4 h-4 text-gray-500" fill="currentColor" viewBox="0 0 20 20"><path fill-rule="evenodd" d="M10 9a3 3 0 100-6 3 3 0 000 6zm-7 9a7 7 0 1114 0H3z" clip-rule="evenodd"></path></svg>
                    </div>
                    <input type="text" name="username" class="flex-1 px-3 text-xs text-gray-700 outline-none placeholder-gray-400 bg-white" placeholder="Username" required>
                </div>

                <div class="flex h-9 border border-gray-300 rounded overflow-hidden shadow-sm hover:border-blue-400 transition-colors group">
                    <div class="w-10 bg-[#f5f5f5] flex items-center justify-center border-r border-gray-300 group-hover:border-blue-400 group-hover:bg-[#ebebeb] transition-colors">
                        <svg class="w-4 h-4 text-gray-500" fill="currentColor" viewBox="0 0 20 20"><path fill-rule="evenodd" d="M18 8a6 6 0 00-12 0v1H5a3 3 0 00-3 3v5a3 3 0 003 3h14a3 3 0 003-3v-5a3 3 0 00-3-3h-1V8zm-6-2a2 2 0 10-4 0v1h4V6z" clip-rule="evenodd"></path></svg>
                    </div>
                    <input type="password" name="password" class="flex-1 px-3 text-xs text-gray-700 outline-none placeholder-gray-400 bg-white" placeholder="Password" required>
                </div>

                <div class="flex items-center justify-between text-[11px] mt-1 px-1">
                    <label class="flex items-center cursor-pointer text-gray-500 select-none hover:text-gray-700">
                        <input type="checkbox" class="rounded border-gray-300 text-blue-500 shadow-sm focus:border-blue-300 focus:ring focus:ring-blue-200 focus:ring-opacity-50 mr-1.5 h-3 w-3">
                        Remember me
                    </label>
                    <a href="index.php?action=forgot_password" class="text-[#2196f3] hover:underline">Forgot Password?</a>
                </div>

                <div class="pt-3">
                    <button type="submit" class="w-full bg-[#2196f3] hover:bg-[#1976d2] text-white text-xs font-bold py-2.5 rounded shadow-md hover:shadow-lg transition-all active:scale-[0.98] tracking-wide">
                        Sign In
                    </button>
                </div>

            </form>
        </div>
    </div>

    <?= \App\Helpers\ViewHelper::footer() ?>

</body>
</html>