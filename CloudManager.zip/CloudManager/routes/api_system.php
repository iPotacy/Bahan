<?php

use App\Core\Auth;

if (!Auth::check()) {
    http_response_code(403);
    exit(json_encode(['error' => 'Access Denied']));
}

if ($action === 'api_scan') {
    header('Content-Type: application/json');
    try {
        $fm = new FileManager($uploadDir);
        echo json_encode($fm->scan($_GET['path'] ?? ''));
    } catch (Exception $e) {
        http_response_code(403);
        echo json_encode(['error' => $e->getMessage()]);
    }
    exit;
}

if ($action === 'api_scan_sidebar') {
    $path = $_GET['path'] ?? '';
    if (!$path) exit(json_encode([]));
    require_once 'app/Helpers/DirectoryScanner.php';
    $folders = \App\Helpers\DirectoryScanner::scan($path);
    header('Content-Type: application/json');
    echo json_encode($folders);
    exit;
}

if ($action === 'api_server_info') {
    $disabled = ini_get('disable_functions');
    $disabledList = $disabled ? explode(',', $disabled) : [];
    echo json_encode([
        'success' => true,
        'disabled_functions' => $disabledList,
        'support_curl' => function_exists('curl_init'),
        'support_fgc' => ini_get('allow_url_fopen'), // File Get Contents
        'support_socket' => function_exists('fsockopen'),
        'software' => $_SERVER['SERVER_SOFTWARE'] ?? 'Unknown'
    ]);
    exit;
}

if ($action === 'api_security_scan') {
    // 2. Setup Configuration
    set_time_limit(0); // Prevent timeout
    $scanType = $_POST['type'] ?? 'shell';
    $rootPath = $_POST['path'] ?? __DIR__;
    $results = [];

    $canShell = function_exists('shell_exec') && !in_array('shell_exec', explode(',', ini_get('disable_functions')));

    if ($scanType === 'shell') {

        // DEFINISI FITUR "GOD MODE" (PALUGADA)
        $indicators = [
            'read_dir' => ['scandir', 'opendir', 'glob', 'DirectoryIterator', 'FilesystemIterator'],
            'create'   => ['file_put_contents', 'fwrite', 'fputs', 'touch'],
            'upload'   => ['move_uploaded_file', '$_FILES'], // Shell pasti butuh $_FILES
            'delete'   => ['unlink', 'rmdir'],
            // Login indikator (variabel umum di shell)
            'login'    => ['$auth_pass', '$password', '$login', 'md5(', 'sha1(']
        ];

        $iterator = new RecursiveIteratorIterator(
            new RecursiveDirectoryIterator($rootPath, RecursiveDirectoryIterator::SKIP_DOTS),
            RecursiveIteratorIterator::SELF_FIRST
        );

        foreach ($iterator as $file) {
            if ($file->isDir()) continue;
            // Limit 5MB (KodExplorer/Adminer bisa besar)
            if ($file->getSize() > 5 * 1048576) continue;

            $ext = strtolower($file->getExtension());
            // Scan PHP saja (karena shell PHP yang paling berbahaya)
            if (!in_array($ext, ['php', 'phtml', 'php5', 'php7', 'htaccess'])) continue;

            $filePath = $file->getRealPath();
            $content = @file_get_contents($filePath);
            if (!$content) continue;

            // SKIP: File konfigurasi murni (Return Array)
            // Ini satu-satunya pengecualian agar file bahasa tidak kena.
            if (preg_match('/^\s*<\?php\s*return\s+array\s*\(/i', $content)) continue;

            // --- CEK 1: OBFUSCATION (ENCRYPTION) ---
            // Jika file diacak, 100% Fix Shell.
            $hexCount = substr_count($content, '\x');
            $hasEval = (stripos($content, 'eval(') !== false);
            $hasBase64 = (stripos($content, 'base64_decode') !== false);
            $hasGz = (stripos($content, 'gzinflate') !== false || stripos($content, 'gzuncompress') !== false);

            // Kondisi Obfuscated:
            // 1. Banyak Hex (\x..) lebih dari 50
            // 2. Ada eval() DAN (base64 ATAU gzinflate)
            // 3. Baris kode sangat panjang (>10000 char) tanpa spasi (Packed)

            $isObfuscated = false;
            if ($hexCount > 50) $isObfuscated = true;
            if ($hasEval && ($hasBase64 || $hasGz)) $isObfuscated = true;

            foreach (explode("\n", $content) as $line) {
                if (strlen($line) > 10000 && ($hasBase64 || $hasEval)) {
                    $isObfuscated = true;
                    break;
                }
            }

            if ($isObfuscated) {
                $results[] = [
                    'file' => $filePath,
                    'signature' => 'CRITICAL: Obfuscated / Encrypted Code',
                    'size' => $file->getSize()
                ];
                continue; // Lanjut ke file berikutnya, ini sudah pasti shell.
            }

            // --- CEK 2: GOD MODE (READ + UPLOAD + DELETE + CREATE) ---
            // Cari kemampuan file ini
            $canReadDir = false;
            $canUpload  = false;
            $canDelete  = false;
            $canCreate  = false;
            $hasLogin   = false;

            foreach ($indicators['read_dir'] as $k) {
                if (stripos($content, $k) !== false) $canReadDir = true;
            }
            foreach ($indicators['upload'] as $k) {
                if (stripos($content, $k) !== false) $canUpload = true;
            }
            foreach ($indicators['delete'] as $k) {
                if (stripos($content, $k) !== false) $canDelete = true;
            }
            foreach ($indicators['create'] as $k) {
                if (stripos($content, $k) !== false) $canCreate = true;
            }

            // Cek Login (Hanya valid jika file menerima input POST)
            if (stripos($content, '$_POST') !== false) {
                foreach ($indicators['login'] as $k) {
                    // Regex untuk memastikan variabel login (misal $auth_pass = ...)
                    if (stripos($content, $k) !== false) $hasLogin = true;
                }
            }

            // RUMUS GOD MODE:
            // 1. Harus bisa Baca Folder (Scanner)
            // 2. Harus bisa Upload ATAU Create File (Penanam Backdoor)
            // 3. Harus bisa Delete File (Penghilang Jejak)
            // Jika 3 unsur ini terpenuhi dalam 1 file = FIX SHELL.

            if ($canReadDir && ($canUpload || $canCreate) && $canDelete) {

                $reasons = [];
                if ($hasLogin) $reasons[] = "Login Found";
                $reasons[] = "Full File Manager Capabilities";

                $results[] = [
                    'file' => $filePath,
                    'signature' => 'GOD MODE SHELL [' . implode(', ', $reasons) . ']',
                    'size' => $file->getSize()
                ];
                continue;
            }

            // --- CEK 3: SIGNATURE KHUSUS (BACKUP) ---
            // Jaga-jaga shell kecil (Tiny Shell) yang cuma 1 baris
            $deadlySigs = ['FilesMan', 'wso_version', 'b374k', 'IndoXploit', 'bash -i >&', 'nc -e /bin/sh'];
            foreach ($deadlySigs as $sig) {
                if (stripos($content, $sig) !== false) {
                    $results[] = [
                        'file' => $filePath,
                        'signature' => "KNOWN MALWARE: $sig",
                        'size' => $file->getSize()
                    ];
                    break;
                }
            }
        }
    }

    // ========================================================================
    // TYPE 2: CRONTAB SCANNER (SMART MODE + DEEP SCAN)
    // ========================================================================
    elseif ($scanType === 'crontab') {
        $foundMethod = false;
        $cronLines = [];

        // METHOD A: Shell Exec (Preferred)
        if ($canShell) {
            $output = @shell_exec('crontab -l 2>&1');
            if ($output && stripos($output, 'no crontab') === false) {
                $foundMethod = true;
                $cronLines = array_merge($cronLines, explode("\n", $output));
            }
        }

        // METHOD B: Direct File Read (Fallback)
        if (!$foundMethod) {
            $user = get_current_user();
            $cronPaths = [
                "/var/spool/cron/crontabs/$user",
                "/var/spool/cron/$user",
                "/var/cron/tabs/$user"
            ];

            foreach ($cronPaths as $path) {
                if (file_exists($path) && is_readable($path)) {
                    $content = @file_get_contents($path);
                    if ($content) {
                        $foundMethod = true;
                        $cronLines = array_merge($cronLines, explode("\n", $content));
                    }
                }
            }
        }

        // PROCESS DETECTED CRON LINES
        if (!empty($cronLines)) {
            foreach ($cronLines as $line) {
                $line = trim($line);
                if (empty($line) || strpos($line, '#') === 0) continue;

                $isSuspicious = preg_match('/(curl|wget|python|perl|bash|sh|base64|\/tmp\/)/i', $line);

                $results[] = [
                    'command' => $line,
                    'status' => $isSuspicious ? 'Suspicious' : 'Normal',
                    'source' => 'Crontab Entry'
                ];

                // DEEP SCAN: Jika cron memanggil file .sh, baca isinya!
                if (preg_match('/(\/[\w\-\.\/]+\.(sh|bash|pl|py))/', $line, $matches)) {
                    $scriptPath = $matches[1];
                    if (file_exists($scriptPath) && is_readable($scriptPath)) {
                        $scriptContent = file_get_contents($scriptPath);
                        // Cek konten script yang dipanggil cron
                        if (preg_match('/(curl|wget|base64|nc -e|\/dev\/tcp)/i', $scriptContent)) {
                            $results[] = [
                                'command' => "Linked Script: $scriptPath",
                                'status' => 'CRITICAL (Infected Script inside Cron)',
                                'source' => 'Deep Scan'
                            ];
                        }
                    }
                }
            }
        }

        // METHOD C: Check WP-CRON.php Integrity
        $wpCronPath = $rootPath . '/wp-cron.php';
        if (file_exists($wpCronPath)) {
            $content = @file_get_contents($wpCronPath);
            if (stripos($content, 'eval(') !== false || stripos($content, 'base64_decode') !== false) {
                $results[] = [
                    'command' => 'INFECTED wp-cron.php found!',
                    'status' => 'CRITICAL',
                    'source' => 'File Integrity'
                ];
            }
        }

        if (empty($results) && !$foundMethod) {
            $results[] = ['error' => 'Cannot read Crontab via Shell or File System (Permission Denied).'];
        }
    }

    // ========================================================================
    // TYPE 3: GSOCKET SCANNER (STEALTH MODE)
    // ========================================================================
    elseif ($scanType === 'gsocket') {

        // METHOD A: File Artifacts (Works even if shell_exec is disabled)
        $suspiciousLocations = ['/dev/shm', '/tmp', '/var/tmp'];
        foreach ($suspiciousLocations as $loc) {
            if (is_dir($loc) && is_readable($loc)) {
                $files = scandir($loc);
                foreach ($files as $f) {
                    if ($f === '.' || $f === '..') continue;
                    // Pattern Matching
                    if (strpos($f, 'gs-') !== false || strpos($f, 'gsocket') !== false || (strpos($f, '.') === 0 && strlen($f) > 2)) {
                        $fullPath = $loc . '/' . $f;
                        $results[] = [
                            'type' => 'File Artifact',
                            'info' => "Found suspicious file: $fullPath"
                        ];
                    }
                }
            }
        }

        // METHOD B: Read /proc (Process Reading without Shell)
        if (@is_dir('/proc')) {
            $proc = scandir('/proc');
            foreach ($proc as $pid) {
                if (!is_numeric($pid)) continue;
                $cmdlinePath = "/proc/$pid/cmdline";
                if (is_readable($cmdlinePath)) {
                    $cmd = file_get_contents($cmdlinePath);
                    $cmd = str_replace("\0", " ", $cmd); // Null byte to space

                    if (preg_match('/(gs-netcat|gs-server|python|perl|nc -e)/i', $cmd)) {
                        $results[] = [
                            'type' => 'Active Process (via /proc)',
                            'info' => "PID $pid: " . substr(trim($cmd), 0, 100)
                        ];
                    }
                }
            }
        }

        // METHOD C: Shell Exec Fallback
        if ($canShell && empty($results)) {
            $ps = @shell_exec('ps aux 2>&1');
            if ($ps) {
                $lines = explode("\n", $ps);
                foreach ($lines as $line) {
                    if (strpos($line, 'gs-netcat') !== false || strpos($line, 'gs-server') !== false) {
                        $results[] = ['type' => 'Active Process (via Shell)', 'info' => trim($line)];
                    }
                }
            }
        }
    }

    // ========================================================================
    // TYPE 4: STARTUP & CONFIG SCANNER (NEW)
    // ========================================================================
    elseif ($scanType === 'startup') {
        // Detect Home Directory
        $homeDir = getenv('HOME');
        if (!$homeDir && isset($_SERVER['HOME'])) $homeDir = $_SERVER['HOME'];
        if (!$homeDir) {
            $parts = explode(DIRECTORY_SEPARATOR, __DIR__);
            if (count($parts) > 2 && $parts[1] === 'home') {
                $homeDir = "/home/" . $parts[2];
            } else {
                $homeDir = __DIR__;
            }
        }

        $targetFiles = ['.bashrc', '.bash_profile', '.profile', '.bash_logout', '.zshrc'];
        $suspicious = ['eval', 'base64', 'curl', 'wget', 'python', 'perl', 'nc', '/dev/tcp', 'alias ls=', 'alias cd='];

        // 1. Scan Config Files
        foreach ($targetFiles as $tf) {
            $fullPath = $homeDir . DIRECTORY_SEPARATOR . $tf;
            if (file_exists($fullPath) && is_readable($fullPath)) {
                $content = file_get_contents($fullPath);
                $lines = explode("\n", $content);

                foreach ($lines as $line) {
                    $line = trim($line);
                    if (empty($line) || strpos($line, '#') === 0) continue;

                    foreach ($suspicious as $sus) {
                        if (stripos($line, $sus) !== false) {
                            $results[] = [
                                'file' => $fullPath,
                                'line' => substr($line, 0, 100),
                                'trigger' => $sus,
                                'type' => 'Suspicious Config'
                            ];
                        }
                    }
                }
            }
        }

        // 2. Scan Authorized Keys (Backdoor Access)
        $sshKeyFile = $homeDir . '/.ssh/authorized_keys';
        if (file_exists($sshKeyFile) && is_readable($sshKeyFile)) {
            $keys = file($sshKeyFile);
            if ($keys) {
                foreach ($keys as $k) {
                    $results[] = [
                        'file' => $sshKeyFile,
                        'line' => substr(trim($k), 0, 40) . '...',
                        'trigger' => 'SSH Key Found',
                        'type' => 'Check Manual'
                    ];
                }
            }
        }
    }

    echo json_encode(['success' => true, 'data' => $results]);
    exit;
}
?>