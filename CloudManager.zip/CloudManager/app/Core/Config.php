<?php
namespace App\Core;

class Config {
    public const DEV_NAME = 'BrotherLine';
    public const APP_NAME = 'BrotherLine Cloud Manager';
    public const APP_VERSION = 'V1.02';
    // public const APP_DEBUG = true;
}