<?php
namespace App\Helpers;

class ThemeHelper {
    
    /**
     * Mengambil satu gambar random dari folder banners
     * @return string Path relative untuk CSS
     */
    public static function getRandomBanner() {
        // Path fisik direktori (untuk PHP scandir)
        $dirPath = __DIR__ . '/../../public/assets/banners/';
        // Path url web (untuk Browser)
        $webPath = 'public/assets/banners/';

        // Cek jika folder ada
        if (!is_dir($dirPath)) return '';

        // Ambil semua file jpg/png/jpeg
        $files = glob($dirPath . '*.{jpg,jpeg,png,webp}', GLOB_BRACE);

        if (empty($files)) {
            // Fallback jika tidak ada gambar
            return 'https://source.unsplash.com/random/1920x1080/?abstract'; 
        }

        // Ambil satu secara acak
        $randomFile = $files[array_rand($files)];
        
        // Kembalikan path web yang bersih (basename mengambil nama filenya saja)
        return $webPath . basename($randomFile);
    }
}