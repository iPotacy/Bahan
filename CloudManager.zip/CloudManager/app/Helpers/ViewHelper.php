<?php
namespace App\Helpers;

use App\Core\Config;

class ViewHelper {
    
    public static function footer($isDarkText = false) {
        $name = Config::DEV_NAME;
        $version = Config::APP_VERSION;
        
        // Jika isDarkText true, pakai text-gray-400. Jika false, pakai text-white/60
        $colorClass = $isDarkText ? 'text-gray-400' : 'text-white/60';
        
        return <<<HTML
        <div class="absolute bottom-6 w-full text-center pointer-events-none z-50">
            <p class="{$colorClass} text-[11px] tracking-wide font-light">
                Powered by {$name} {$version}
            </p>
        </div>
HTML;
    }
}