<?php

namespace App\Helpers;

class DirectoryScanner
{

    private static function formatBytes($bytes, $precision = 0)
    {
        if ($bytes <= 0) return '0 KB';
        $units = ['B', 'KB', 'MB', 'GB', 'TB'];
        $bytes = max($bytes, 0);
        $pow = floor(($bytes ? log($bytes) : 0) / log(1024));
        $pow = min($pow, count($units) - 1);
        $bytes /= pow(1024, $pow);
        return round($bytes, $precision) . ' ' . $units[$pow];
    }

    public static function getWindowsDrives()
    {
        $drives = [];
        foreach (range('A', 'Z') as $letter) {
            if (is_dir($letter . ':\\')) {
                $drives[] = [
                    'name' => "Local Disk ($letter:)",
                    'path' => $letter . ':/',
                    'type' => 'drive',
                    'has_children' => true,
                    'size' => '',
                    'date' => '',
                    'ext' => 'Local Disk'
                ];
            }
        }
        return $drives;
    }

    public static function scan($dir)
    {
        $result = [];

        // 1. Validasi Path Kosong
        if (!$dir || empty($dir)) return [];

        // 2. Jika Windows Root
        if ($dir === 'COMPUTER_ROOT') {
            return self::getWindowsDrives();
        }

        // 3. Cek apakah folder ada dan bisa dibaca
        if (!is_dir($dir) || !is_readable($dir)) {
            // Opsional: Log error jika perlu
            // error_log("CloudManager: Cannot read directory $dir");
            return [];
        }

        // 4. SCAN FOLDER (Tanpa @ agar kita tahu jika error di log)
        // Gunakan try-catch untuk safety
        try {
            $items = scandir($dir);
            if ($items === false) return [];
        } catch (\Exception $e) {
            return [];
        }

        $skipList = ['.', '..', '$Recycle.Bin', 'System Volume Information', 'Recovery', 'Pagefile.sys'];

        foreach ($items as $item) {
            if (in_array($item, $skipList)) continue;

            $path = $dir . DIRECTORY_SEPARATOR . $item;
            $path = str_replace(['\\', '//'], '/', $path); // Normalisasi Path

            $isDir = is_dir($path);
            $size = '';
            $date = '';
            $type = '';
            $ext = '';
            $hasChildren = false;
            $permissions = []; // Array Permission

            // --- LOGIC PERMISSION ---
            if (is_readable($path)) $permissions[] = 'Read';
            if (is_writable($path)) $permissions[] = 'Edit';
            if (is_writable($dir))  $permissions[] = 'Delete'; // Delete butuh izin tulis ke FOLDER INDUK
            if (empty($permissions)) $permissions[] = 'Locked';

            // --- INFO FILE ---
            if (file_exists($path)) {
                $timestamp = @filemtime($path);
                if ($timestamp) $date = date("d/m/Y H:i", $timestamp);
            }

            if ($isDir) {
                $type = 'folder';
                $ext = 'File folder';
                // Cek anak folder (Optimasi: scandir ringan)
                $subItems = @scandir($path);
                if ($subItems) {
                    foreach ($subItems as $sub) {
                        if ($sub !== '.' && $sub !== '..') {
                            $hasChildren = true;
                            break;
                        }
                    }
                }
            } else {
                $type = 'file';
                $bytes = @filesize($path);
                $size = self::formatBytes($bytes);
                $info = pathinfo($path);
                $ext = isset($info['extension']) ? strtoupper($info['extension']) . ' File' : 'File';
            }

            $result[] = [
                'name' => $item,
                'path' => $path,
                'has_children' => $hasChildren,
                'type' => $type,
                'ext' => $ext,
                'size' => $size,
                'date' => $date,
                'perms' => $permissions
            ];
        }
        return $result;
    }
}
