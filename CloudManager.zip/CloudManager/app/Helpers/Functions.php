<?php

function recurse_copy($src, $dst)
{
    $dir = opendir($src);
    if (!is_dir($dst)) {
        mkdir($dst, 0755, true);
    }
    while (false !== ($file = readdir($dir))) {
        if (($file != '.') && ($file != '..')) {
            $srcPath = $src . DIRECTORY_SEPARATOR . $file;
            $dstPath = $dst . DIRECTORY_SEPARATOR . $file;

            if (is_dir($srcPath)) {
                // Rekursif untuk folder
                recurse_copy($srcPath, $dstPath);
            } else {
                // Copy file
                copy($srcPath, $dstPath);
                // Windows akan mengabaikan ini, jadi aman.
                chmod($dstPath, 0644);
            }
        }
    }
    closedir($dir);
}
?>